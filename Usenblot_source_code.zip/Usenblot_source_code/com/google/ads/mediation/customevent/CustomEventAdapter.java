package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.customevent.CustomEventExtras;
import com.google.android.gms.internal.da;

public final class CustomEventAdapter implements MediationBannerAdapter<CustomEventExtras, CustomEventServerParameters>, MediationInterstitialAdapter<CustomEventExtras, CustomEventServerParameters> {
    private View f19m;
    private CustomEventBanner f20n;
    private CustomEventInterstitial f21o;

    /* renamed from: com.google.ads.mediation.customevent.CustomEventAdapter.a */
    private static final class C0101a implements CustomEventBannerListener {
        private final MediationBannerListener f14k;
        private final CustomEventAdapter f15p;

        public C0101a(CustomEventAdapter customEventAdapter, MediationBannerListener mediationBannerListener) {
            this.f15p = customEventAdapter;
            this.f14k = mediationBannerListener;
        }

        public void onClick() {
            da.m1269s("Custom event adapter called onFailedToReceiveAd.");
            this.f14k.onClick(this.f15p);
        }

        public void onDismissScreen() {
            da.m1269s("Custom event adapter called onFailedToReceiveAd.");
            this.f14k.onDismissScreen(this.f15p);
        }

        public void onFailedToReceiveAd() {
            da.m1269s("Custom event adapter called onFailedToReceiveAd.");
            this.f14k.onFailedToReceiveAd(this.f15p, ErrorCode.NO_FILL);
        }

        public void onLeaveApplication() {
            da.m1269s("Custom event adapter called onFailedToReceiveAd.");
            this.f14k.onLeaveApplication(this.f15p);
        }

        public void onPresentScreen() {
            da.m1269s("Custom event adapter called onFailedToReceiveAd.");
            this.f14k.onPresentScreen(this.f15p);
        }

        public void onReceivedAd(View view) {
            da.m1269s("Custom event adapter called onReceivedAd.");
            this.f15p.m3a(view);
            this.f14k.onReceivedAd(this.f15p);
        }
    }

    /* renamed from: com.google.ads.mediation.customevent.CustomEventAdapter.b */
    private class C0102b implements CustomEventInterstitialListener {
        private final MediationInterstitialListener f16l;
        private final CustomEventAdapter f17p;
        final /* synthetic */ CustomEventAdapter f18q;

        public C0102b(CustomEventAdapter customEventAdapter, CustomEventAdapter customEventAdapter2, MediationInterstitialListener mediationInterstitialListener) {
            this.f18q = customEventAdapter;
            this.f17p = customEventAdapter2;
            this.f16l = mediationInterstitialListener;
        }

        public void onDismissScreen() {
            da.m1269s("Custom event adapter called onDismissScreen.");
            this.f16l.onDismissScreen(this.f17p);
        }

        public void onFailedToReceiveAd() {
            da.m1269s("Custom event adapter called onFailedToReceiveAd.");
            this.f16l.onFailedToReceiveAd(this.f17p, ErrorCode.NO_FILL);
        }

        public void onLeaveApplication() {
            da.m1269s("Custom event adapter called onLeaveApplication.");
            this.f16l.onLeaveApplication(this.f17p);
        }

        public void onPresentScreen() {
            da.m1269s("Custom event adapter called onPresentScreen.");
            this.f16l.onPresentScreen(this.f17p);
        }

        public void onReceivedAd() {
            da.m1269s("Custom event adapter called onReceivedAd.");
            this.f16l.onReceivedAd(this.f18q);
        }
    }

    private static <T> T m2a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            da.m1273w("Could not instantiate custom event adapter: " + str + ". " + th.getMessage());
            return null;
        }
    }

    private void m3a(View view) {
        this.f19m = view;
    }

    public void destroy() {
        if (this.f20n != null) {
            this.f20n.destroy();
        }
        if (this.f21o != null) {
            this.f21o.destroy();
        }
    }

    public Class<CustomEventExtras> getAdditionalParametersType() {
        return CustomEventExtras.class;
    }

    public View getBannerView() {
        return this.f19m;
    }

    public Class<CustomEventServerParameters> getServerParametersType() {
        return CustomEventServerParameters.class;
    }

    public void requestBannerAd(MediationBannerListener listener, Activity activity, CustomEventServerParameters serverParameters, AdSize adSize, MediationAdRequest mediationAdRequest, CustomEventExtras customEventExtras) {
        this.f20n = (CustomEventBanner) m2a(serverParameters.className);
        if (this.f20n == null) {
            listener.onFailedToReceiveAd(this, ErrorCode.INTERNAL_ERROR);
        } else {
            this.f20n.requestBannerAd(new C0101a(this, listener), activity, serverParameters.label, serverParameters.parameter, adSize, mediationAdRequest, customEventExtras == null ? null : customEventExtras.getExtra(serverParameters.label));
        }
    }

    public void requestInterstitialAd(MediationInterstitialListener listener, Activity activity, CustomEventServerParameters serverParameters, MediationAdRequest mediationAdRequest, CustomEventExtras customEventExtras) {
        this.f21o = (CustomEventInterstitial) m2a(serverParameters.className);
        if (this.f21o == null) {
            listener.onFailedToReceiveAd(this, ErrorCode.INTERNAL_ERROR);
        } else {
            this.f21o.requestInterstitialAd(new C0102b(this, this, listener), activity, serverParameters.label, serverParameters.parameter, mediationAdRequest, customEventExtras == null ? null : customEventExtras.getExtra(serverParameters.label));
        }
    }

    public void showInterstitial() {
        this.f21o.showInterstitial();
    }
}
