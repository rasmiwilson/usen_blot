package com.google.ads.mediation.jsadapter;

import android.app.Activity;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.AdSize;
import com.google.ads.mediation.EmptyNetworkExtras;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.android.gms.internal.da;

public final class JavascriptAdapter implements MediationBannerAdapter<EmptyNetworkExtras, JavascriptServerParameters> {
    private WebView f34C;
    private FrameLayout f35D;
    private boolean f36E;
    private MediationBannerListener f37k;
    private int f38v;
    private int f39w;

    public void destroy() {
        this.f36E = true;
    }

    public Class<EmptyNetworkExtras> getAdditionalParametersType() {
        return EmptyNetworkExtras.class;
    }

    public View getBannerView() {
        return this.f35D;
    }

    public Class<JavascriptServerParameters> getServerParametersType() {
        return JavascriptServerParameters.class;
    }

    public WebView getWebView() {
        return this.f34C;
    }

    public int getWebViewHeight() {
        return this.f38v;
    }

    public int getWebViewWidth() {
        return this.f39w;
    }

    public void passbackReceived() {
        da.m1269s("Passback received");
        sendAdNotReceivedUpdate();
    }

    public void requestBannerAd(MediationBannerListener listener, Activity activity, JavascriptServerParameters serverParameters, AdSize adSize, MediationAdRequest mediationAdRequest, EmptyNetworkExtras extras) {
        this.f37k = listener;
        this.f38v = serverParameters.height != null ? serverParameters.height.intValue() : adSize.getHeightInPixels(activity);
        this.f39w = serverParameters.width != null ? serverParameters.width.intValue() : adSize.getWidthInPixels(activity);
        this.f36E = false;
        this.f34C = new WebView(activity);
        this.f34C.getSettings().setJavaScriptEnabled(true);
        this.f34C.setWebViewClient(new BannerWebViewClient(this, serverParameters.passBackUrl));
        this.f34C.setBackgroundColor(0);
        this.f35D = new FrameLayout(activity);
        this.f35D.addView(this.f34C, new LayoutParams(this.f39w, this.f38v, 17));
        this.f34C.loadDataWithBaseURL(null, serverParameters.htmlScript, "text/html", "utf-8", null);
    }

    public void sendAdNotReceivedUpdate() {
        if (!this.f36E) {
            this.f36E = true;
            this.f37k.onFailedToReceiveAd(this, ErrorCode.NO_FILL);
        }
    }

    public void sendAdReceivedUpdate() {
        if (!this.f36E) {
            this.f36E = true;
            this.f37k.onReceivedAd(this);
        }
    }

    public boolean shouldStopAdCheck() {
        return this.f36E;
    }

    public void startCheckingForAd() {
        new AdViewCheckTask(this, 200, 100).start();
    }
}
