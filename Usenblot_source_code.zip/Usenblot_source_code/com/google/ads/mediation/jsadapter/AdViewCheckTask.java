package com.google.ads.mediation.jsadapter;

import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.view.View.MeasureSpec;
import android.webkit.WebView;
import com.google.android.gms.internal.da;

public final class AdViewCheckTask implements Runnable {
    public static final int BACKGROUND_COLOR = 0;
    private final JavascriptAdapter f27r;
    private final Handler f28s;
    private final long f29t;
    private long f30u;

    /* renamed from: com.google.ads.mediation.jsadapter.AdViewCheckTask.a */
    private final class C0103a extends AsyncTask<Void, Void, Boolean> {
        private final int f22v;
        private final int f23w;
        private final WebView f24x;
        private Bitmap f25y;
        final /* synthetic */ AdViewCheckTask f26z;

        public C0103a(AdViewCheckTask adViewCheckTask, int i, int i2, WebView webView) {
            this.f26z = adViewCheckTask;
            this.f22v = i2;
            this.f23w = i;
            this.f24x = webView;
        }

        protected synchronized Boolean m5a(Void... voidArr) {
            Boolean valueOf;
            int width = this.f25y.getWidth();
            int height = this.f25y.getHeight();
            if (width == 0 || height == 0) {
                valueOf = Boolean.valueOf(false);
            } else {
                int i = 0;
                for (int i2 = 0; i2 < width; i2 += 10) {
                    for (int i3 = 0; i3 < height; i3 += 10) {
                        if (this.f25y.getPixel(i2, i3) != 0) {
                            i++;
                        }
                    }
                }
                valueOf = Boolean.valueOf(((double) i) / (((double) (width * height)) / 100.0d) > 0.1d);
            }
            return valueOf;
        }

        protected void m6a(Boolean bool) {
            AdViewCheckTask.m7a(this.f26z);
            if (bool.booleanValue()) {
                this.f26z.f27r.sendAdReceivedUpdate();
            } else if (this.f26z.f30u > 0) {
                if (da.m1268n(2)) {
                    da.m1269s("Ad not detected, scheduling another run.");
                }
                this.f26z.f28s.postDelayed(this.f26z, this.f26z.f29t);
            } else {
                da.m1269s("Ad not detected, Not scheduling anymore runs.");
                this.f26z.f27r.sendAdNotReceivedUpdate();
            }
        }

        protected /* synthetic */ Object doInBackground(Object[] x0) {
            return m5a((Void[]) x0);
        }

        protected /* synthetic */ void onPostExecute(Object x0) {
            m6a((Boolean) x0);
        }

        protected synchronized void onPreExecute() {
            this.f25y = Bitmap.createBitmap(this.f23w, this.f22v, Config.ARGB_8888);
            this.f24x.setVisibility(0);
            this.f24x.measure(MeasureSpec.makeMeasureSpec(this.f23w, 0), MeasureSpec.makeMeasureSpec(this.f22v, 0));
            this.f24x.layout(0, 0, this.f23w, this.f22v);
            this.f24x.draw(new Canvas(this.f25y));
            this.f24x.invalidate();
        }
    }

    public AdViewCheckTask(JavascriptAdapter adapter, long checkIntervalInMillis, long numIterations) {
        this.f27r = adapter;
        this.f29t = checkIntervalInMillis;
        this.f30u = numIterations;
        this.f28s = new Handler(Looper.getMainLooper());
    }

    static /* synthetic */ long m7a(AdViewCheckTask adViewCheckTask) {
        long j = adViewCheckTask.f30u - 1;
        adViewCheckTask.f30u = j;
        return j;
    }

    public void run() {
        if (this.f27r != null && !this.f27r.shouldStopAdCheck()) {
            new C0103a(this, this.f27r.getWebViewWidth(), this.f27r.getWebViewHeight(), this.f27r.getWebView()).execute(new Void[0]);
        }
    }

    public void start() {
        this.f28s.postDelayed(this, this.f29t);
    }
}
