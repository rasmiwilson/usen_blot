package com.google.ads.mediation.admob;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import com.google.ads.AdRequest.Gender;
import com.google.ads.AdSize;
import com.google.ads.mediation.MediationAdRequest;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.mediation.NetworkExtras;
import com.google.android.gms.ads.mediation.admob.AdMobExtras;
import com.google.android.gms.internal.bk;
import com.google.android.gms.internal.cz;
import java.util.Date;
import java.util.Set;

public final class AdMobAdapter implements MediationBannerAdapter<AdMobExtras, AdMobServerParameters>, MediationInterstitialAdapter<AdMobExtras, AdMobServerParameters> {
    private AdView f12h;
    private InterstitialAd f13i;

    /* renamed from: com.google.ads.mediation.admob.AdMobAdapter.a */
    private static final class C0099a extends AdListener {
        private final AdMobAdapter f8j;
        private final MediationBannerListener f9k;

        public C0099a(AdMobAdapter adMobAdapter, MediationBannerListener mediationBannerListener) {
            this.f8j = adMobAdapter;
            this.f9k = mediationBannerListener;
        }

        public void onAdClosed() {
            this.f9k.onDismissScreen(this.f8j);
        }

        public void onAdFailedToLoad(int errorCode) {
            this.f9k.onFailedToReceiveAd(this.f8j, bk.m1040h(errorCode));
        }

        public void onAdLeftApplication() {
            this.f9k.onLeaveApplication(this.f8j);
        }

        public void onAdLoaded() {
            this.f9k.onReceivedAd(this.f8j);
        }

        public void onAdOpened() {
            this.f9k.onClick(this.f8j);
            this.f9k.onPresentScreen(this.f8j);
        }
    }

    /* renamed from: com.google.ads.mediation.admob.AdMobAdapter.b */
    private static final class C0100b extends AdListener {
        private final AdMobAdapter f10j;
        private final MediationInterstitialListener f11l;

        public C0100b(AdMobAdapter adMobAdapter, MediationInterstitialListener mediationInterstitialListener) {
            this.f10j = adMobAdapter;
            this.f11l = mediationInterstitialListener;
        }

        public void onAdClosed() {
            this.f11l.onDismissScreen(this.f10j);
        }

        public void onAdFailedToLoad(int errorCode) {
            this.f11l.onFailedToReceiveAd(this.f10j, bk.m1040h(errorCode));
        }

        public void onAdLeftApplication() {
            this.f11l.onLeaveApplication(this.f10j);
        }

        public void onAdLoaded() {
            this.f11l.onReceivedAd(this.f10j);
        }

        public void onAdOpened() {
            this.f11l.onPresentScreen(this.f10j);
        }
    }

    private static AdRequest m1a(Context context, MediationAdRequest mediationAdRequest, AdMobExtras adMobExtras, AdMobServerParameters adMobServerParameters) {
        NetworkExtras adMobExtras2;
        Builder builder = new Builder();
        Date birthday = mediationAdRequest.getBirthday();
        if (birthday != null) {
            builder.setBirthday(birthday);
        }
        Gender gender = mediationAdRequest.getGender();
        if (gender != null) {
            builder.setGender(bk.m1036a(gender));
        }
        Set<String> keywords = mediationAdRequest.getKeywords();
        if (keywords != null) {
            for (String addKeyword : keywords) {
                builder.addKeyword(addKeyword);
            }
        }
        if (mediationAdRequest.isTesting()) {
            builder.addTestDevice(cz.m1258l(context));
        }
        if (adMobServerParameters.tagForChildDirectedTreatment != -1) {
            builder.tagForChildDirectedTreatment(adMobServerParameters.tagForChildDirectedTreatment == 1);
        }
        if (adMobExtras == null) {
            adMobExtras2 = new AdMobExtras(new Bundle());
        }
        Bundle extras = adMobExtras2.getExtras();
        extras.putInt("gw", 1);
        extras.putString("mad_hac", adMobServerParameters.allowHouseAds);
        if (!TextUtils.isEmpty(adMobServerParameters.adJson)) {
            extras.putString("_ad", adMobServerParameters.adJson);
        }
        extras.putBoolean("_noRefresh", true);
        builder.addNetworkExtras(adMobExtras2);
        return builder.build();
    }

    public void destroy() {
        if (this.f12h != null) {
            this.f12h.destroy();
            this.f12h = null;
        }
        if (this.f13i != null) {
            this.f13i = null;
        }
    }

    public Class<AdMobExtras> getAdditionalParametersType() {
        return AdMobExtras.class;
    }

    public View getBannerView() {
        return this.f12h;
    }

    public Class<AdMobServerParameters> getServerParametersType() {
        return AdMobServerParameters.class;
    }

    public void requestBannerAd(MediationBannerListener bannerListener, Activity activity, AdMobServerParameters serverParameters, AdSize adSize, MediationAdRequest mediationAdRequest, AdMobExtras extras) {
        this.f12h = new AdView(activity);
        this.f12h.setAdSize(new com.google.android.gms.ads.AdSize(adSize.getWidth(), adSize.getHeight()));
        this.f12h.setAdUnitId(serverParameters.adUnitId);
        this.f12h.setAdListener(new C0099a(this, bannerListener));
        this.f12h.loadAd(m1a(activity, mediationAdRequest, extras, serverParameters));
    }

    public void requestInterstitialAd(MediationInterstitialListener interstitialListener, Activity activity, AdMobServerParameters serverParameters, MediationAdRequest mediationAdRequest, AdMobExtras extras) {
        this.f13i = new InterstitialAd(activity);
        this.f13i.setAdUnitId(serverParameters.adUnitId);
        this.f13i.setAdListener(new C0100b(this, interstitialListener));
        this.f13i.loadAd(m1a(activity, mediationAdRequest, extras, serverParameters));
    }

    public void showInterstitial() {
        this.f13i.show();
    }
}
