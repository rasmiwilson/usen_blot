package com.google.android.gms.auth;

public class UserRecoverableNotifiedException extends GoogleAuthException {
    public UserRecoverableNotifiedException(String err) {
        super(err);
    }
}
