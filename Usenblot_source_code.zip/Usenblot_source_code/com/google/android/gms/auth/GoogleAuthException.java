package com.google.android.gms.auth;

public class GoogleAuthException extends Exception {
    public GoogleAuthException(String err) {
        super(err);
    }
}
