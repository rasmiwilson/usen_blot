package com.google.android.gms.analytics;

import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import com.google.analytics.tracking.android.Fields;
import com.google.android.gcm.GCMConstants;
import com.google.android.gms.analytics.C0172u.C0171a;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class GoogleAnalytics extends TrackerHandler {
    private static boolean tB;
    private static GoogleAnalytics tI;
    private Context mContext;
    private String qR;
    private String qS;
    private C0145f rk;
    private boolean tC;
    private af tD;
    private volatile Boolean tE;
    private Logger tF;
    private Set<C0122a> tG;
    private boolean tH;

    /* renamed from: com.google.android.gms.analytics.GoogleAnalytics.a */
    interface C0122a {
        void m42f(Activity activity);

        void m43g(Activity activity);
    }

    /* renamed from: com.google.android.gms.analytics.GoogleAnalytics.b */
    class C0123b implements ActivityLifecycleCallbacks {
        final /* synthetic */ GoogleAnalytics tJ;

        C0123b(GoogleAnalytics googleAnalytics) {
            this.tJ = googleAnalytics;
        }

        public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        }

        public void onActivityDestroyed(Activity activity) {
        }

        public void onActivityPaused(Activity activity) {
        }

        public void onActivityResumed(Activity activity) {
        }

        public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
        }

        public void onActivityStarted(Activity activity) {
            this.tJ.m49d(activity);
        }

        public void onActivityStopped(Activity activity) {
            this.tJ.m50e(activity);
        }
    }

    protected GoogleAnalytics(Context context) {
        this(context, C0170t.m177q(context), C0156r.bB());
    }

    private GoogleAnalytics(Context context, C0145f thread, af serviceManager) {
        this.tE = Boolean.valueOf(false);
        this.tH = false;
        if (context == null) {
            throw new IllegalArgumentException("context cannot be null");
        }
        this.mContext = context.getApplicationContext();
        this.rk = thread;
        this.tD = serviceManager;
        C0146g.m127n(this.mContext);
        ae.m84n(this.mContext);
        C0148h.m132n(this.mContext);
        this.tF = new C0150l();
        this.tG = new HashSet();
        cg();
    }

    private int m45D(String str) {
        String toLowerCase = str.toLowerCase();
        return "verbose".equals(toLowerCase) ? 0 : "info".equals(toLowerCase) ? 1 : "warning".equals(toLowerCase) ? 2 : GCMConstants.EXTRA_ERROR.equals(toLowerCase) ? 3 : -1;
    }

    private Tracker m46a(Tracker tracker) {
        if (this.qR != null) {
            tracker.set(Fields.APP_NAME, this.qR);
        }
        if (this.qS != null) {
            tracker.set(Fields.APP_VERSION, this.qS);
        }
        return tracker;
    }

    static GoogleAnalytics cf() {
        GoogleAnalytics googleAnalytics;
        synchronized (GoogleAnalytics.class) {
            googleAnalytics = tI;
        }
        return googleAnalytics;
    }

    private void cg() {
        if (!tB) {
            ApplicationInfo applicationInfo;
            try {
                applicationInfo = this.mContext.getPackageManager().getApplicationInfo(this.mContext.getPackageName(), 129);
            } catch (NameNotFoundException e) {
                aa.m64v("PackageManager doesn't know about package: " + e);
                applicationInfo = null;
            }
            if (applicationInfo == null) {
                aa.m65w("Couldn't get ApplicationInfo to load gloabl config.");
                return;
            }
            Bundle bundle = applicationInfo.metaData;
            if (bundle != null) {
                int i = bundle.getInt("com.google.android.gms.analytics.globalConfigResource");
                if (i > 0) {
                    C0175w c0175w = (C0175w) new C0174v(this.mContext).m106p(i);
                    if (c0175w != null) {
                        m52a(c0175w);
                    }
                }
            }
        }
    }

    private void m49d(Activity activity) {
        for (C0122a f : this.tG) {
            f.m42f(activity);
        }
    }

    private void m50e(Activity activity) {
        for (C0122a g : this.tG) {
            g.m43g(activity);
        }
    }

    public static GoogleAnalytics getInstance(Context context) {
        GoogleAnalytics googleAnalytics;
        synchronized (GoogleAnalytics.class) {
            if (tI == null) {
                tI = new GoogleAnalytics(context);
            }
            googleAnalytics = tI;
        }
        return googleAnalytics;
    }

    void m51a(C0122a c0122a) {
        this.tG.add(c0122a);
    }

    void m52a(C0175w c0175w) {
        aa.m64v("Loading global config values.");
        if (c0175w.bV()) {
            this.qR = c0175w.bW();
            aa.m64v("app name loaded: " + this.qR);
        }
        if (c0175w.bX()) {
            this.qS = c0175w.bY();
            aa.m64v("app version loaded: " + this.qS);
        }
        if (c0175w.bZ()) {
            int D = m45D(c0175w.ca());
            if (D >= 0) {
                aa.m64v("log level loaded: " + D);
                getLogger().setLogLevel(D);
            }
        }
        if (c0175w.cb()) {
            this.tD.setLocalDispatchPeriod(c0175w.cc());
        }
        if (c0175w.cd()) {
            setDryRun(c0175w.ce());
        }
    }

    void m53b(C0122a c0122a) {
        this.tG.remove(c0122a);
    }

    @Deprecated
    public void dispatchLocalHits() {
        this.tD.dispatchLocalHits();
    }

    public void enableAutoActivityReports(Application application) {
        if (VERSION.SDK_INT >= 14 && !this.tH) {
            application.registerActivityLifecycleCallbacks(new C0123b(this));
            this.tH = true;
        }
    }

    public boolean getAppOptOut() {
        C0172u.bR().m183a(C0171a.GET_APP_OPT_OUT);
        return this.tE.booleanValue();
    }

    public Logger getLogger() {
        return this.tF;
    }

    public boolean isDryRunEnabled() {
        C0172u.bR().m183a(C0171a.GET_DRY_RUN);
        return this.tC;
    }

    void m54n(Map<String, String> map) {
        synchronized (this) {
            if (map == null) {
                throw new IllegalArgumentException("hit cannot be null");
            }
            ak.m113a(map, Fields.LANGUAGE, ak.m112a(Locale.getDefault()));
            ak.m113a(map, Fields.SCREEN_RESOLUTION, ae.cs().getValue(Fields.SCREEN_RESOLUTION));
            map.put("&_u", C0172u.bR().bT());
            C0172u.bR().bS();
            this.rk.m126n(map);
        }
    }

    public Tracker newTracker(int configResId) {
        Tracker a;
        synchronized (this) {
            C0172u.bR().m183a(C0171a.GET_TRACKER);
            Tracker tracker = new Tracker(null, this);
            if (configResId > 0) {
                aj ajVar = (aj) new ai(this.mContext).m106p(configResId);
                if (ajVar != null) {
                    tracker.m60a(this.mContext, ajVar);
                }
            }
            a = m46a(tracker);
        }
        return a;
    }

    public Tracker newTracker(String trackingId) {
        Tracker a;
        synchronized (this) {
            C0172u.bR().m183a(C0171a.GET_TRACKER);
            a = m46a(new Tracker(trackingId, this));
        }
        return a;
    }

    public void reportActivityStart(Activity activity) {
        if (!this.tH) {
            m49d(activity);
        }
    }

    public void reportActivityStop(Activity activity) {
        if (!this.tH) {
            m50e(activity);
        }
    }

    public void setAppOptOut(boolean optOut) {
        C0172u.bR().m183a(C0171a.SET_APP_OPT_OUT);
        this.tE = Boolean.valueOf(optOut);
        if (this.tE.booleanValue()) {
            this.rk.bk();
        }
    }

    public void setDryRun(boolean dryRun) {
        C0172u.bR().m183a(C0171a.SET_DRY_RUN);
        this.tC = dryRun;
    }

    @Deprecated
    public void setLocalDispatchPeriod(int dispatchPeriodInSeconds) {
        this.tD.setLocalDispatchPeriod(dispatchPeriodInSeconds);
    }

    public void setLogger(Logger logger) {
        C0172u.bR().m183a(C0171a.SET_LOGGER);
        this.tF = logger;
    }
}
