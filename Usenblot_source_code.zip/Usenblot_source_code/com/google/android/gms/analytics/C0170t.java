package com.google.android.gms.analytics;

import android.content.Context;
import android.os.Process;
import android.support.v4.os.EnvironmentCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.text.TextUtils;
import com.google.analytics.tracking.android.Fields;
import com.google.android.gms.analytics.internal.Command;
import com.google.android.gms.internal.di;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

/* renamed from: com.google.android.gms.analytics.t */
class C0170t extends Thread implements C0145f {
    private static C0170t sd;
    private volatile boolean mClosed;
    private final Context mContext;
    private volatile String qX;
    private final LinkedBlockingQueue<Runnable> rZ;
    private volatile boolean sa;
    private volatile List<di> sb;
    private volatile String sc;
    private volatile ag se;

    /* renamed from: com.google.android.gms.analytics.t.1 */
    class C01661 implements Runnable {
        final /* synthetic */ Map sf;
        final /* synthetic */ C0170t sg;

        C01661(C0170t c0170t, Map map) {
            this.sg = c0170t;
            this.sf = map;
        }

        public void run() {
            if (TextUtils.isEmpty((CharSequence) this.sf.get(Fields.CLIENT_ID))) {
                this.sf.put(Fields.CLIENT_ID, this.sg.qX);
            }
            if (!GoogleAnalytics.getInstance(this.sg.mContext).getAppOptOut() && !this.sg.m176p(this.sf)) {
                if (!TextUtils.isEmpty(this.sg.sc)) {
                    C0172u.bR().m184r(true);
                    this.sf.putAll(new HitBuilder().setCampaignParamsFromUrl(this.sg.sc).build());
                    C0172u.bR().m184r(false);
                    this.sg.sc = null;
                }
                this.sg.m180r(this.sf);
                this.sg.m178q(this.sf);
                this.sg.se.m87b(C0177y.m192s(this.sf), Long.valueOf((String) this.sf.get("&ht")).longValue(), this.sg.m175o(this.sf), this.sg.sb);
            }
        }
    }

    /* renamed from: com.google.android.gms.analytics.t.2 */
    class C01672 implements Runnable {
        final /* synthetic */ C0170t sg;

        C01672(C0170t c0170t) {
            this.sg = c0170t;
        }

        public void run() {
            this.sg.se.bp();
        }
    }

    /* renamed from: com.google.android.gms.analytics.t.3 */
    class C01683 implements Runnable {
        final /* synthetic */ C0170t sg;

        C01683(C0170t c0170t) {
            this.sg = c0170t;
        }

        public void run() {
            this.sg.se.bk();
        }
    }

    /* renamed from: com.google.android.gms.analytics.t.4 */
    class C01694 implements Runnable {
        final /* synthetic */ C0170t sg;

        C01694(C0170t c0170t) {
            this.sg = c0170t;
        }

        public void run() {
            this.sg.se.br();
        }
    }

    private C0170t(Context context) {
        super("GAThread");
        this.rZ = new LinkedBlockingQueue();
        this.sa = false;
        this.mClosed = false;
        if (context != null) {
            this.mContext = context.getApplicationContext();
        } else {
            this.mContext = context;
        }
        start();
    }

    static int m163C(String str) {
        int i = 1;
        if (!TextUtils.isEmpty(str)) {
            i = 0;
            for (int length = str.length() - 1; length >= 0; length--) {
                char charAt = str.charAt(length);
                i = (((i << 6) & 268435455) + charAt) + (charAt << 14);
                int i2 = 266338304 & i;
                if (i2 != 0) {
                    i ^= i2 >> 21;
                }
            }
        }
        return i;
    }

    private String m166a(Throwable th) {
        OutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        PrintStream printStream = new PrintStream(byteArrayOutputStream);
        th.printStackTrace(printStream);
        printStream.flush();
        return new String(byteArrayOutputStream.toByteArray());
    }

    private String m175o(Map<String, String> map) {
        return map.containsKey(Fields.USE_SECURE) ? ak.m114d((String) map.get(Fields.USE_SECURE), true) ? "https:" : "http:" : "https:";
    }

    private boolean m176p(Map<String, String> map) {
        if (map.get(Fields.SAMPLE_RATE) == null) {
            return false;
        }
        double a = ak.m111a((String) map.get(Fields.SAMPLE_RATE), 100.0d);
        if (a >= 100.0d) {
            return false;
        }
        if (((double) (C0170t.m163C((String) map.get(Fields.CLIENT_ID)) % 10000)) < a * 100.0d) {
            return false;
        }
        String str = map.get(Fields.HIT_TYPE) == null ? EnvironmentCompat.MEDIA_UNKNOWN : (String) map.get(Fields.HIT_TYPE);
        aa.m64v(String.format("%s hit sampled out", new Object[]{str}));
        return true;
    }

    static C0170t m177q(Context context) {
        if (sd == null) {
            sd = new C0170t(context);
        }
        return sd;
    }

    private void m178q(Map<String, String> map) {
        C0129m m = C0130a.m61m(this.mContext);
        ak.m113a(map, "&adid", m.getValue("&adid"));
        ak.m113a(map, "&ate", m.getValue("&ate"));
    }

    static String m179r(Context context) {
        try {
            FileInputStream openFileInput = context.openFileInput("gaInstallData");
            byte[] bArr = new byte[AccessibilityNodeInfoCompat.ACTION_SCROLL_BACKWARD];
            int read = openFileInput.read(bArr, 0, AccessibilityNodeInfoCompat.ACTION_SCROLL_BACKWARD);
            if (openFileInput.available() > 0) {
                aa.m62t("Too much campaign data, ignoring it.");
                openFileInput.close();
                context.deleteFile("gaInstallData");
                return null;
            }
            openFileInput.close();
            context.deleteFile("gaInstallData");
            if (read <= 0) {
                aa.m65w("Campaign file is empty.");
                return null;
            }
            String str = new String(bArr, 0, read);
            aa.m63u("Campaign found: " + str);
            return str;
        } catch (FileNotFoundException e) {
            aa.m63u("No campaign data found.");
            return null;
        } catch (IOException e2) {
            aa.m62t("Error reading campaign data.");
            context.deleteFile("gaInstallData");
            return null;
        }
    }

    private void m180r(Map<String, String> map) {
        C0129m bt = C0146g.bt();
        ak.m113a(map, Fields.APP_NAME, bt.getValue(Fields.APP_NAME));
        ak.m113a(map, Fields.APP_VERSION, bt.getValue(Fields.APP_VERSION));
        ak.m113a(map, Fields.APP_ID, bt.getValue(Fields.APP_ID));
        ak.m113a(map, Fields.APP_INSTALLER_ID, bt.getValue(Fields.APP_INSTALLER_ID));
        map.put("&v", "1");
    }

    void m181a(Runnable runnable) {
        this.rZ.add(runnable);
    }

    public void bk() {
        m181a(new C01683(this));
    }

    public void bp() {
        m181a(new C01672(this));
    }

    public void br() {
        m181a(new C01694(this));
    }

    public LinkedBlockingQueue<Runnable> bs() {
        return this.rZ;
    }

    public Thread getThread() {
        return this;
    }

    protected void init() {
        this.se.bI();
        this.sb = new ArrayList();
        this.sb.add(new di(Command.APPEND_VERSION, "&_v".substring(1), "ma4.0.0"));
        this.sb.add(new di(Command.APPEND_QUEUE_TIME, "&qt".substring(1), null));
        this.sb.add(new di(Command.APPEND_CACHE_BUSTER, "&z".substring(1), null));
    }

    public void m182n(Map<String, String> map) {
        Map hashMap = new HashMap(map);
        String str = (String) map.get("&ht");
        if (str != null) {
            try {
                Long.valueOf(str);
            } catch (NumberFormatException e) {
                str = null;
            }
        }
        if (str == null) {
            hashMap.put("&ht", Long.toString(System.currentTimeMillis()));
        }
        m181a(new C01661(this, hashMap));
    }

    public void run() {
        Process.setThreadPriority(10);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            aa.m65w("sleep interrupted in GAThread initialize");
        }
        try {
            if (this.se == null) {
                this.se = new C0165s(this.mContext, this);
            }
            init();
            this.qX = C0148h.bu().getValue(Fields.CLIENT_ID);
            if (this.qX == null) {
                this.sa = true;
            }
            this.sc = C0170t.m179r(this.mContext);
            aa.m64v("Initialized GA Thread");
        } catch (Throwable th) {
            aa.m62t("Error initializing the GAThread: " + m166a(th));
            aa.m62t("Google Analytics will not start up.");
            this.sa = true;
        }
        while (!this.mClosed) {
            try {
                Runnable runnable = (Runnable) this.rZ.take();
                if (!this.sa) {
                    runnable.run();
                }
            } catch (InterruptedException e2) {
                aa.m63u(e2.toString());
            } catch (Throwable th2) {
                aa.m62t("Error on GAThread: " + m166a(th2));
                aa.m62t("Google Analytics is shutting down.");
                this.sa = true;
            }
        }
    }
}
