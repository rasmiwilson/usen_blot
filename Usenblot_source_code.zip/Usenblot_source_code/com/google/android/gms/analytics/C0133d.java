package com.google.android.gms.analytics;

import com.google.android.gms.internal.di;
import java.util.Collection;
import java.util.Map;

/* renamed from: com.google.android.gms.analytics.d */
interface C0133d {
    void m69a(Map<String, String> map, long j, String str, Collection<di> collection);

    void bp();

    C0134n bq();

    void m70i(long j);
}
