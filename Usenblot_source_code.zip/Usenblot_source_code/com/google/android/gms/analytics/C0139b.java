package com.google.android.gms.analytics;

import com.google.android.gms.internal.di;
import java.util.List;
import java.util.Map;

/* renamed from: com.google.android.gms.analytics.b */
interface C0139b {
    void m116a(Map<String, String> map, long j, String str, List<di> list);

    void bk();

    void connect();

    void disconnect();
}
