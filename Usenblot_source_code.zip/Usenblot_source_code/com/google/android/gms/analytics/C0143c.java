package com.google.android.gms.analytics;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.internal.di;
import com.google.android.gms.internal.dj;
import com.google.android.gms.internal.dj.C0520a;
import java.util.List;
import java.util.Map;

/* renamed from: com.google.android.gms.analytics.c */
class C0143c implements C0139b {
    private Context mContext;
    private ServiceConnection qM;
    private C0141b qN;
    private C0142c qO;
    private dj qP;

    /* renamed from: com.google.android.gms.analytics.c.a */
    final class C0140a implements ServiceConnection {
        final /* synthetic */ C0143c qQ;

        C0140a(C0143c c0143c) {
            this.qQ = c0143c;
        }

        public void onServiceConnected(ComponentName component, IBinder binder) {
            aa.m64v("service connected, binder: " + binder);
            try {
                if ("com.google.android.gms.analytics.internal.IAnalyticsService".equals(binder.getInterfaceDescriptor())) {
                    aa.m64v("bound to service");
                    this.qQ.qP = C0520a.m1304r(binder);
                    this.qQ.bn();
                    return;
                }
            } catch (RemoteException e) {
            }
            this.qQ.mContext.unbindService(this);
            this.qQ.qM = null;
            this.qQ.qO.m117a(2, null);
        }

        public void onServiceDisconnected(ComponentName component) {
            aa.m64v("service disconnected: " + component);
            this.qQ.qM = null;
            this.qQ.qN.onDisconnected();
        }
    }

    /* renamed from: com.google.android.gms.analytics.c.b */
    public interface C0141b {
        void onConnected();

        void onDisconnected();
    }

    /* renamed from: com.google.android.gms.analytics.c.c */
    public interface C0142c {
        void m117a(int i, Intent intent);
    }

    public C0143c(Context context, C0141b c0141b, C0142c c0142c) {
        this.mContext = context;
        if (c0141b == null) {
            throw new IllegalArgumentException("onConnectedListener cannot be null");
        }
        this.qN = c0141b;
        if (c0142c == null) {
            throw new IllegalArgumentException("onConnectionFailedListener cannot be null");
        }
        this.qO = c0142c;
    }

    private dj bl() {
        bm();
        return this.qP;
    }

    private void bn() {
        bo();
    }

    private void bo() {
        this.qN.onConnected();
    }

    public void m124a(Map<String, String> map, long j, String str, List<di> list) {
        try {
            bl().m1302a(map, j, str, list);
        } catch (RemoteException e) {
            aa.m62t("sendHit failed: " + e);
        }
    }

    public void bk() {
        try {
            bl().bk();
        } catch (RemoteException e) {
            aa.m62t("clear hits failed: " + e);
        }
    }

    protected void bm() {
        if (!isConnected()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    public void connect() {
        Intent intent = new Intent("com.google.android.gms.analytics.service.START");
        intent.setComponent(new ComponentName(GooglePlayServicesUtil.GOOGLE_PLAY_SERVICES_PACKAGE, "com.google.android.gms.analytics.service.AnalyticsService"));
        intent.putExtra(AnalyticsGmsCoreClient.KEY_APP_PACKAGE_NAME, this.mContext.getPackageName());
        if (this.qM != null) {
            aa.m62t("Calling connect() while still connected, missing disconnect().");
            return;
        }
        this.qM = new C0140a(this);
        boolean bindService = this.mContext.bindService(intent, this.qM, 129);
        aa.m64v("connect: bindService returned " + bindService + " for " + intent);
        if (!bindService) {
            this.qM = null;
            this.qO.m117a(1, null);
        }
    }

    public void disconnect() {
        this.qP = null;
        if (this.qM != null) {
            try {
                this.mContext.unbindService(this.qM);
            } catch (IllegalStateException e) {
            } catch (IllegalArgumentException e2) {
            }
            this.qM = null;
            this.qN.onDisconnected();
        }
    }

    public boolean isConnected() {
        return this.qP != null;
    }
}
