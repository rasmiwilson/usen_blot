package com.google.android.gms.analytics;

/* renamed from: com.google.android.gms.analytics.i */
interface C0125i {
    long currentTimeMillis();
}
