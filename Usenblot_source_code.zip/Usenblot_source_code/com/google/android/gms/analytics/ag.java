package com.google.android.gms.analytics;

import com.google.android.gms.internal.di;
import java.util.List;
import java.util.Map;

interface ag {
    void m87b(Map<String, String> map, long j, String str, List<di> list);

    void bI();

    void bk();

    void bp();

    void br();
}
