package com.google.android.gms.analytics;

/* renamed from: com.google.android.gms.analytics.w */
class C0175w implements C0138j {
    String qR;
    String qS;
    int tA;
    String ty;
    int tz;

    C0175w() {
        this.tz = -1;
        this.tA = -1;
    }

    public boolean bV() {
        return this.qR != null;
    }

    public String bW() {
        return this.qR;
    }

    public boolean bX() {
        return this.qS != null;
    }

    public String bY() {
        return this.qS;
    }

    public boolean bZ() {
        return this.ty != null;
    }

    public String ca() {
        return this.ty;
    }

    public boolean cb() {
        return this.tz >= 0;
    }

    public int cc() {
        return this.tz;
    }

    public boolean cd() {
        return this.tA != -1;
    }

    public boolean ce() {
        return this.tA == 1;
    }
}
