package com.google.android.gms.analytics;

abstract class af {
    af() {
    }

    abstract void bF();

    abstract void dispatchLocalHits();

    abstract void m86q(boolean z);

    abstract void setLocalDispatchPeriod(int i);
}
