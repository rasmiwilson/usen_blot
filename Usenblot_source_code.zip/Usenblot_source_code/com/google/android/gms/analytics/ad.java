package com.google.android.gms.analytics;

interface ad {
    boolean cl();
}
