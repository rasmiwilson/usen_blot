package com.google.android.gms.analytics;

import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

/* renamed from: com.google.android.gms.analytics.f */
interface C0145f {
    void bk();

    void bp();

    void br();

    LinkedBlockingQueue<Runnable> bs();

    Thread getThread();

    void m126n(Map<String, String> map);
}
