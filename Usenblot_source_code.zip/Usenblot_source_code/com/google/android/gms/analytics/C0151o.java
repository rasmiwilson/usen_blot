package com.google.android.gms.analytics;

import com.appsgeyser.sdk.configuration.Constants;
import com.google.analytics.tracking.android.Fields;

/* renamed from: com.google.android.gms.analytics.o */
final class C0151o {
    private static String m136b(String str, int i) {
        if (i >= 1) {
            return str + i;
        }
        aa.m62t("index out of range for " + str + " (" + i + ")");
        return Constants.PUBLISHER_NAME;
    }

    static String m137q(int i) {
        return C0151o.m136b(Fields.SCREEN_NAME, i);
    }

    static String m138r(int i) {
        return C0151o.m136b(Fields.CAMPAIGN_MEDIUM, i);
    }
}
