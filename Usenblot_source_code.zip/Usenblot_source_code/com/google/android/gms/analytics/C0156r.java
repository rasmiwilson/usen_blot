package com.google.android.gms.analytics;

import android.content.Context;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import com.google.android.gms.analytics.C0172u.C0171a;
import com.google.android.gms.location.LocationStatusCodes;

/* renamed from: com.google.android.gms.analytics.r */
class C0156r extends af {
    private static final Object ri;
    private static C0156r ru;
    private Context mContext;
    private Handler mHandler;
    private C0133d rj;
    private volatile C0145f rk;
    private int rl;
    private boolean rm;
    private boolean rn;
    private String ro;
    private boolean rp;
    private boolean rq;
    private C0144e rr;
    private C0153q rs;
    private boolean rt;

    /* renamed from: com.google.android.gms.analytics.r.1 */
    class C01541 implements C0144e {
        final /* synthetic */ C0156r rv;

        C01541(C0156r c0156r) {
            this.rv = c0156r;
        }

        public void m142p(boolean z) {
            this.rv.m148a(z, this.rv.rp);
        }
    }

    /* renamed from: com.google.android.gms.analytics.r.2 */
    class C01552 implements Callback {
        final /* synthetic */ C0156r rv;

        C01552(C0156r c0156r) {
            this.rv = c0156r;
        }

        public boolean handleMessage(Message msg) {
            if (1 == msg.what && C0156r.ri.equals(msg.obj)) {
                C0172u.bR().m184r(true);
                this.rv.dispatchLocalHits();
                C0172u.bR().m184r(false);
                if (this.rv.rl > 0 && !this.rv.rt) {
                    this.rv.mHandler.sendMessageDelayed(this.rv.mHandler.obtainMessage(1, C0156r.ri), (long) (this.rv.rl * LocationStatusCodes.GEOFENCE_NOT_AVAILABLE));
                }
            }
            return true;
        }
    }

    static {
        ri = new Object();
    }

    private C0156r() {
        this.rl = 1800;
        this.rm = true;
        this.rp = true;
        this.rq = true;
        this.rr = new C01541(this);
        this.rt = false;
    }

    public static C0156r bB() {
        if (ru == null) {
            ru = new C0156r();
        }
        return ru;
    }

    private void bC() {
        this.rs = new C0153q(this);
        this.rs.m141o(this.mContext);
    }

    private void bD() {
        this.mHandler = new Handler(this.mContext.getMainLooper(), new C01552(this));
        if (this.rl > 0) {
            this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1, ri), (long) (this.rl * LocationStatusCodes.GEOFENCE_NOT_AVAILABLE));
        }
    }

    synchronized void m147a(Context context, C0145f c0145f) {
        if (this.mContext == null) {
            this.mContext = context.getApplicationContext();
            if (this.rk == null) {
                this.rk = c0145f;
                if (this.rm) {
                    dispatchLocalHits();
                    this.rm = false;
                }
                if (this.rn) {
                    br();
                    this.rn = false;
                }
            }
        }
    }

    synchronized void m148a(boolean z, boolean z2) {
        if (!(this.rt == z && this.rp == z2)) {
            if (z || !z2) {
                if (this.rl > 0) {
                    this.mHandler.removeMessages(1, ri);
                }
            }
            if (!z && z2 && this.rl > 0) {
                this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1, ri), (long) (this.rl * LocationStatusCodes.GEOFENCE_NOT_AVAILABLE));
            }
            StringBuilder append = new StringBuilder().append("PowerSaveMode ");
            String str = (z || !z2) ? "initiated." : "terminated.";
            aa.m64v(append.append(str).toString());
            this.rt = z;
            this.rp = z2;
        }
    }

    synchronized C0133d bE() {
        if (this.rj == null) {
            if (this.mContext == null) {
                throw new IllegalStateException("Cant get a store unless we have a context");
            }
            this.rj = new ac(this.rr, this.mContext);
            if (this.ro != null) {
                this.rj.bq().m88A(this.ro);
                this.ro = null;
            }
        }
        if (this.mHandler == null) {
            bD();
        }
        if (this.rs == null && this.rq) {
            bC();
        }
        return this.rj;
    }

    synchronized void bF() {
        if (!this.rt && this.rp && this.rl > 0) {
            this.mHandler.removeMessages(1, ri);
            this.mHandler.sendMessage(this.mHandler.obtainMessage(1, ri));
        }
    }

    void br() {
        if (this.rk == null) {
            aa.m64v("setForceLocalDispatch() queued. It will be called once initialization is complete.");
            this.rn = true;
            return;
        }
        C0172u.bR().m183a(C0171a.SET_FORCE_LOCAL_DISPATCH);
        this.rk.br();
    }

    synchronized void dispatchLocalHits() {
        if (this.rk == null) {
            aa.m64v("Dispatch call queued. Dispatch will run once initialization is complete.");
            this.rm = true;
        } else {
            C0172u.bR().m183a(C0171a.DISPATCH);
            this.rk.bp();
        }
    }

    synchronized void m149q(boolean z) {
        m148a(this.rt, z);
    }

    synchronized void setLocalDispatchPeriod(int dispatchPeriodInSeconds) {
        if (this.mHandler == null) {
            aa.m64v("Dispatch period set with null handler. Dispatch will run once initialization is complete.");
            this.rl = dispatchPeriodInSeconds;
        } else {
            C0172u.bR().m183a(C0171a.SET_DISPATCH_PERIOD);
            if (!this.rt && this.rp && this.rl > 0) {
                this.mHandler.removeMessages(1, ri);
            }
            this.rl = dispatchPeriodInSeconds;
            if (dispatchPeriodInSeconds > 0 && !this.rt && this.rp) {
                this.mHandler.sendMessageDelayed(this.mHandler.obtainMessage(1, ri), (long) (dispatchPeriodInSeconds * LocationStatusCodes.GEOFENCE_NOT_AVAILABLE));
            }
        }
    }
}
