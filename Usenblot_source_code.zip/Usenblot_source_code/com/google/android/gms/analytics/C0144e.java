package com.google.android.gms.analytics;

/* renamed from: com.google.android.gms.analytics.e */
interface C0144e {
    void m125p(boolean z);
}
