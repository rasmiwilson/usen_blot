package com.google.android.gms.analytics;

import java.util.List;

/* renamed from: com.google.android.gms.analytics.n */
interface C0134n {
    void m88A(String str);

    int m89a(List<C0176x> list, ab abVar, boolean z);

    boolean bA();
}
