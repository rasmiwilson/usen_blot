package com.google.android.gms.analytics;

import android.content.Context;
import com.google.android.gms.analytics.C0137k.C0135a;

/* renamed from: com.google.android.gms.analytics.v */
class C0174v extends C0137k<C0175w> {

    /* renamed from: com.google.android.gms.analytics.v.a */
    private static class C0173a implements C0135a<C0175w> {
        private final C0175w tx;

        public C0173a() {
            this.tx = new C0175w();
        }

        public void m185a(String str, int i) {
            if ("ga_dispatchPeriod".equals(str)) {
                this.tx.tz = i;
            } else {
                aa.m65w("int configuration name not recognized:  " + str);
            }
        }

        public void m186a(String str, String str2) {
        }

        public void m187b(String str, String str2) {
            if ("ga_appName".equals(str)) {
                this.tx.qR = str2;
            } else if ("ga_appVersion".equals(str)) {
                this.tx.qS = str2;
            } else if ("ga_logLevel".equals(str)) {
                this.tx.ty = str2;
            } else {
                aa.m65w("string configuration name not recognized:  " + str);
            }
        }

        public C0175w bU() {
            return this.tx;
        }

        public /* synthetic */ C0138j bz() {
            return bU();
        }

        public void m188c(String str, boolean z) {
            if ("ga_dryRun".equals(str)) {
                this.tx.tA = z ? 1 : 0;
                return;
            }
            aa.m65w("bool configuration name not recognized:  " + str);
        }
    }

    public C0174v(Context context) {
        super(context, new C0173a());
    }
}
