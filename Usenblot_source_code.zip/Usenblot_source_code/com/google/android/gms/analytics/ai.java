package com.google.android.gms.analytics;

import android.content.Context;
import com.google.android.gms.analytics.C0137k.C0135a;

class ai extends C0137k<aj> {

    /* renamed from: com.google.android.gms.analytics.ai.a */
    private static class C0136a implements C0135a<aj> {
        private final aj uJ;

        public C0136a() {
            this.uJ = new aj();
        }

        public void m101a(String str, int i) {
            if ("ga_sessionTimeout".equals(str)) {
                this.uJ.uM = i;
            } else {
                aa.m65w("int configuration name not recognized:  " + str);
            }
        }

        public void m102a(String str, String str2) {
            this.uJ.uQ.put(str, str2);
        }

        public void m103b(String str, String str2) {
            if ("ga_trackingId".equals(str)) {
                this.uJ.uK = str2;
            } else if ("ga_sampleFrequency".equals(str)) {
                try {
                    this.uJ.uL = Double.parseDouble(str2);
                } catch (NumberFormatException e) {
                    aa.m62t("Error parsing ga_sampleFrequency value: " + str2);
                }
            } else {
                aa.m65w("string configuration name not recognized:  " + str);
            }
        }

        public /* synthetic */ C0138j bz() {
            return cA();
        }

        public void m104c(String str, boolean z) {
            int i = 1;
            aj ajVar;
            if ("ga_autoActivityTracking".equals(str)) {
                ajVar = this.uJ;
                if (!z) {
                    i = 0;
                }
                ajVar.uN = i;
            } else if ("ga_anonymizeIp".equals(str)) {
                ajVar = this.uJ;
                if (!z) {
                    i = 0;
                }
                ajVar.uO = i;
            } else if ("ga_reportUncaughtExceptions".equals(str)) {
                ajVar = this.uJ;
                if (!z) {
                    i = 0;
                }
                ajVar.uP = i;
            } else {
                aa.m65w("bool configuration name not recognized:  " + str);
            }
        }

        public aj cA() {
            return this.uJ;
        }
    }

    public ai(Context context) {
        super(context, new C0136a());
    }
}
