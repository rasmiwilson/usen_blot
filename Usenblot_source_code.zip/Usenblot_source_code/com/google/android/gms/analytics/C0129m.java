package com.google.android.gms.analytics;

/* renamed from: com.google.android.gms.analytics.m */
interface C0129m {
    String getValue(String str);
}
