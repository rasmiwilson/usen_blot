package com.google.android.gms.appstate;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.C0179b;
import com.google.android.gms.common.api.Api.C0236a;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.C0239a.C0184a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Releasable;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.er;

public final class AppStateManager {
    public static final Api API;
    public static final Scope SCOPE_APP_STATE;
    static final C0179b<dl> va;

    /* renamed from: com.google.android.gms.appstate.AppStateManager.1 */
    static class C01801 implements C0179b<dl> {
        C01801() {
        }

        public dl m194a(Context context, Looper looper, ee eeVar, ApiOptions apiOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return new dl(context, looper, connectionCallbacks, onConnectionFailedListener, eeVar.dR(), (String[]) eeVar.dT().toArray(new String[0]));
        }

        public /* synthetic */ C0236a m195b(Context context, Looper looper, ee eeVar, ApiOptions apiOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return m194a(context, looper, eeVar, apiOptions, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    public interface StateResult extends Releasable, Result {
        StateConflictResult getConflictResult();

        StateLoadedResult getLoadedResult();
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.2 */
    static class C01812 implements StateResult {
        final /* synthetic */ Status vb;

        C01812(Status status) {
            this.vb = status;
        }

        public StateConflictResult getConflictResult() {
            return null;
        }

        public StateLoadedResult getLoadedResult() {
            return null;
        }

        public Status getStatus() {
            return this.vb;
        }

        public void release() {
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.a */
    public static abstract class C0185a<R extends Result> extends C0184a<R, dl> implements PendingResult<R> {
        public C0185a() {
            super(AppStateManager.va);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.e */
    private static abstract class C0186e extends C0185a<StateResult> {
        private C0186e() {
        }

        public /* synthetic */ Result m206d(Status status) {
            return m207g(status);
        }

        public StateResult m207g(Status status) {
            return AppStateManager.m228a(status);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.3 */
    static class C01873 extends C0186e {
        final /* synthetic */ int vc;
        final /* synthetic */ byte[] vd;

        C01873(int i, byte[] bArr) {
            this.vc = i;
            this.vd = bArr;
            super();
        }

        protected void m209a(dl dlVar) {
            dlVar.m1331a(null, this.vc, this.vd);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.4 */
    static class C01884 extends C0186e {
        final /* synthetic */ int vc;
        final /* synthetic */ byte[] vd;

        C01884(int i, byte[] bArr) {
            this.vc = i;
            this.vd = bArr;
            super();
        }

        protected void m211a(dl dlVar) {
            dlVar.m1331a(this, this.vc, this.vd);
        }
    }

    public interface StateDeletedResult extends Result {
        int getStateKey();
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.b */
    private static abstract class C0190b extends C0185a<StateDeletedResult> {
        private C0190b() {
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.5 */
    static class C01915 extends C0190b {
        final /* synthetic */ int vc;

        /* renamed from: com.google.android.gms.appstate.AppStateManager.5.1 */
        class C01891 implements StateDeletedResult {
            final /* synthetic */ Status vb;
            final /* synthetic */ C01915 ve;

            C01891(C01915 c01915, Status status) {
                this.ve = c01915;
                this.vb = status;
            }

            public int getStateKey() {
                return this.ve.vc;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        C01915(int i) {
            this.vc = i;
            super();
        }

        protected void m213a(dl dlVar) {
            dlVar.m1329a((C0182c) this, this.vc);
        }

        public StateDeletedResult m214c(Status status) {
            return new C01891(this, status);
        }

        public /* synthetic */ Result m215d(Status status) {
            return m214c(status);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.6 */
    static class C01926 extends C0186e {
        final /* synthetic */ int vc;

        C01926(int i) {
            this.vc = i;
            super();
        }

        protected void m217a(dl dlVar) {
            dlVar.m1334b(this, this.vc);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.c */
    private static abstract class C0193c extends C0185a<StateListResult> {

        /* renamed from: com.google.android.gms.appstate.AppStateManager.c.1 */
        class C01981 implements StateListResult {
            final /* synthetic */ Status vb;
            final /* synthetic */ C0193c vh;

            C01981(C0193c c0193c, Status status) {
                this.vh = c0193c;
                this.vb = status;
            }

            public AppStateBuffer getStateBuffer() {
                return new AppStateBuffer(null);
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        private C0193c() {
        }

        public /* synthetic */ Result m218d(Status status) {
            return m219e(status);
        }

        public StateListResult m219e(Status status) {
            return new C01981(this, status);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.7 */
    static class C01947 extends C0193c {
        C01947() {
            super();
        }

        protected void m221a(dl dlVar) {
            dlVar.m1328a(this);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.8 */
    static class C01958 extends C0186e {
        final /* synthetic */ int vc;
        final /* synthetic */ String vf;
        final /* synthetic */ byte[] vg;

        C01958(int i, String str, byte[] bArr) {
            this.vc = i;
            this.vf = str;
            this.vg = bArr;
            super();
        }

        protected void m223a(dl dlVar) {
            dlVar.m1330a(this, this.vc, this.vf, this.vg);
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.d */
    private static abstract class C0196d extends C0185a<Status> {
        private C0196d() {
        }

        public /* synthetic */ Result m224d(Status status) {
            return m225f(status);
        }

        public Status m225f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.appstate.AppStateManager.9 */
    static class C01979 extends C0196d {
        C01979() {
            super();
        }

        protected void m227a(dl dlVar) {
            dlVar.m1333b((C0182c) this);
        }
    }

    public interface StateConflictResult extends Releasable, Result {
        byte[] getLocalData();

        String getResolvedVersion();

        byte[] getServerData();

        int getStateKey();
    }

    public interface StateListResult extends Result {
        AppStateBuffer getStateBuffer();
    }

    public interface StateLoadedResult extends Releasable, Result {
        byte[] getLocalData();

        int getStateKey();
    }

    static {
        va = new C01801();
        SCOPE_APP_STATE = new Scope(Scopes.APP_STATE);
        API = new Api(va, SCOPE_APP_STATE);
    }

    private AppStateManager() {
    }

    private static StateResult m228a(Status status) {
        return new C01812(status);
    }

    public static dl m229a(GoogleApiClient googleApiClient) {
        boolean z = true;
        er.m1550b(googleApiClient != null, (Object) "GoogleApiClient parameter is required.");
        er.m1547a(googleApiClient.isConnected(), "GoogleApiClient must be connected.");
        dl dlVar = (dl) googleApiClient.m364a(va);
        if (dlVar == null) {
            z = false;
        }
        er.m1547a(z, "GoogleApiClient is not configured to use the AppState API. Pass AppStateManager.API into GoogleApiClient.Builder#addApi() to use this feature.");
        return dlVar;
    }

    public static PendingResult<StateDeletedResult> delete(GoogleApiClient googleApiClient, int stateKey) {
        return googleApiClient.m366b(new C01915(stateKey));
    }

    public static int getMaxNumKeys(GoogleApiClient googleApiClient) {
        return m229a(googleApiClient).cO();
    }

    public static int getMaxStateSize(GoogleApiClient googleApiClient) {
        return m229a(googleApiClient).cN();
    }

    public static PendingResult<StateListResult> list(GoogleApiClient googleApiClient) {
        return googleApiClient.m365a(new C01947());
    }

    public static PendingResult<StateResult> load(GoogleApiClient googleApiClient, int stateKey) {
        return googleApiClient.m365a(new C01926(stateKey));
    }

    public static PendingResult<StateResult> resolve(GoogleApiClient googleApiClient, int stateKey, String resolvedVersion, byte[] resolvedData) {
        return googleApiClient.m366b(new C01958(stateKey, resolvedVersion, resolvedData));
    }

    public static PendingResult<Status> signOut(GoogleApiClient googleApiClient) {
        return googleApiClient.m366b(new C01979());
    }

    public static void update(GoogleApiClient googleApiClient, int stateKey, byte[] data) {
        googleApiClient.m366b(new C01873(stateKey, data));
    }

    public static PendingResult<StateResult> updateImmediate(GoogleApiClient googleApiClient, int stateKey, byte[] data) {
        return googleApiClient.m366b(new C01884(stateKey, data));
    }
}
