package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.location.LocationStatusCodes;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

public class DataHolderCreator implements Creator<DataHolder> {
    public static final int CONTENT_DESCRIPTION = 0;

    static void m402a(DataHolder dataHolder, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m497a(parcel, 1, dataHolder.dH(), false);
        C0265b.m501c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, dataHolder.getVersionCode());
        C0265b.m496a(parcel, 2, dataHolder.dI(), i, false);
        C0265b.m501c(parcel, 3, dataHolder.getStatusCode());
        C0265b.m486a(parcel, 4, dataHolder.getMetadata(), false);
        C0265b.m481D(parcel, p);
    }

    public DataHolder createFromParcel(Parcel parcel) {
        int i = 0;
        Bundle bundle = null;
        int o = C0264a.m466o(parcel);
        CursorWindow[] cursorWindowArr = null;
        String[] strArr = null;
        int i2 = 0;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    strArr = C0264a.m476x(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    cursorWindowArr = (CursorWindow[]) C0264a.m451b(parcel, n, CursorWindow.CREATOR);
                    break;
                case Error.BAD_CVC /*3*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    bundle = C0264a.m467o(parcel, n);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i2 = C0264a.m457g(parcel, n);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() != o) {
            throw new C0263a("Overread allowed size end=" + o, parcel);
        }
        DataHolder dataHolder = new DataHolder(i2, strArr, cursorWindowArr, i, bundle);
        dataHolder.validateContents();
        return dataHolder;
    }

    public DataHolder[] newArray(int size) {
        return new DataHolder[size];
    }
}
