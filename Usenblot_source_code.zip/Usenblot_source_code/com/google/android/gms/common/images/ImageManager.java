package com.google.android.gms.common.images;

import android.app.ActivityManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import android.util.Log;
import android.widget.ImageView;
import com.google.android.gms.common.images.C0261a.C0260a;
import com.google.android.gms.internal.ed;
import com.google.android.gms.internal.ev;
import com.google.android.gms.internal.fr;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageManager {
    private static final Object Ar;
    private static HashSet<Uri> As;
    private static ImageManager At;
    private static ImageManager Au;
    private final ExecutorService Av;
    private final C0255b Aw;
    private final Map<C0261a, ImageReceiver> Ax;
    private final Map<Uri, ImageReceiver> Ay;
    private final Context mContext;
    private final Handler mHandler;

    private final class ImageReceiver extends ResultReceiver {
        boolean AA;
        final /* synthetic */ ImageManager AB;
        private final ArrayList<C0261a> Az;
        private final Uri mUri;

        ImageReceiver(ImageManager imageManager, Uri uri) {
            this.AB = imageManager;
            super(new Handler(Looper.getMainLooper()));
            this.AA = false;
            this.mUri = uri;
            this.Az = new ArrayList();
        }

        public void m408c(C0261a c0261a) {
            ed.m1459a(!this.AA, "Cannot add an ImageRequest when mHandlingRequests is true");
            ed.ac("ImageReceiver.addImageRequest() must be called in the main thread");
            this.Az.add(c0261a);
        }

        public void m409d(C0261a c0261a) {
            ed.m1459a(!this.AA, "Cannot remove an ImageRequest when mHandlingRequests is true");
            ed.ac("ImageReceiver.removeImageRequest() must be called in the main thread");
            this.Az.remove(c0261a);
        }

        public void dN() {
            Intent intent = new Intent("com.google.android.gms.common.images.LOAD_IMAGE");
            intent.putExtra("com.google.android.gms.extras.uri", this.mUri);
            intent.putExtra("com.google.android.gms.extras.resultReceiver", this);
            intent.putExtra("com.google.android.gms.extras.priority", 3);
            this.AB.mContext.sendBroadcast(intent);
        }

        public void onReceiveResult(int resultCode, Bundle resultData) {
            this.AB.Av.execute(new C0256c(this.AB, this.mUri, (ParcelFileDescriptor) resultData.getParcelable("com.google.android.gms.extra.fileDescriptor")));
        }
    }

    public interface OnImageLoadedListener {
        void onImageLoaded(Uri uri, Drawable drawable, boolean z);
    }

    /* renamed from: com.google.android.gms.common.images.ImageManager.a */
    private static final class C0254a {
        static int m410a(ActivityManager activityManager) {
            return activityManager.getLargeMemoryClass();
        }
    }

    /* renamed from: com.google.android.gms.common.images.ImageManager.b */
    private static final class C0255b extends ev<C0260a, Bitmap> {
        public C0255b(Context context) {
            super(C0255b.m412w(context));
        }

        private static int m412w(Context context) {
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            int memoryClass = (((context.getApplicationInfo().flags & AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START) != 0 ? 1 : null) == null || !fr.eJ()) ? activityManager.getMemoryClass() : C0254a.m410a(activityManager);
            return (int) (((float) (memoryClass * AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_START)) * 0.33f);
        }

        protected int m413a(C0260a c0260a, Bitmap bitmap) {
            return bitmap.getHeight() * bitmap.getRowBytes();
        }

        protected void m414a(boolean z, C0260a c0260a, Bitmap bitmap, Bitmap bitmap2) {
            super.entryRemoved(z, c0260a, bitmap, bitmap2);
        }

        protected /* synthetic */ void entryRemoved(boolean x0, Object x1, Object x2, Object x3) {
            m414a(x0, (C0260a) x1, (Bitmap) x2, (Bitmap) x3);
        }

        protected /* synthetic */ int sizeOf(Object x0, Object x1) {
            return m413a((C0260a) x0, (Bitmap) x1);
        }
    }

    /* renamed from: com.google.android.gms.common.images.ImageManager.c */
    private final class C0256c implements Runnable {
        final /* synthetic */ ImageManager AB;
        private final ParcelFileDescriptor AC;
        private final Uri mUri;

        public C0256c(ImageManager imageManager, Uri uri, ParcelFileDescriptor parcelFileDescriptor) {
            this.AB = imageManager;
            this.mUri = uri;
            this.AC = parcelFileDescriptor;
        }

        public void run() {
            ed.ad("LoadBitmapFromDiskRunnable can't be executed in the main thread");
            boolean z = false;
            Bitmap bitmap = null;
            if (this.AC != null) {
                try {
                    bitmap = BitmapFactory.decodeFileDescriptor(this.AC.getFileDescriptor());
                } catch (Throwable e) {
                    Log.e("ImageManager", "OOM while loading bitmap for uri: " + this.mUri, e);
                    z = true;
                }
                try {
                    this.AC.close();
                } catch (Throwable e2) {
                    Log.e("ImageManager", "closed failed", e2);
                }
            }
            CountDownLatch countDownLatch = new CountDownLatch(1);
            this.AB.mHandler.post(new C0259f(this.AB, this.mUri, bitmap, z, countDownLatch));
            try {
                countDownLatch.await();
            } catch (InterruptedException e3) {
                Log.w("ImageManager", "Latch interrupted while posting " + this.mUri);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.images.ImageManager.d */
    private final class C0257d implements Runnable {
        final /* synthetic */ ImageManager AB;
        private final C0261a AD;

        public C0257d(ImageManager imageManager, C0261a c0261a) {
            this.AB = imageManager;
            this.AD = c0261a;
        }

        public void run() {
            ed.ac("LoadImageRunnable must be executed on the main thread");
            this.AB.m422b(this.AD);
            C0260a c0260a = this.AD.AF;
            if (c0260a.uri == null) {
                this.AD.m438b(this.AB.mContext, true);
                return;
            }
            Bitmap a = this.AB.m418a(c0260a);
            if (a != null) {
                this.AD.m435a(this.AB.mContext, a, true);
                return;
            }
            this.AD.m439x(this.AB.mContext);
            ImageReceiver imageReceiver = (ImageReceiver) this.AB.Ay.get(c0260a.uri);
            if (imageReceiver == null) {
                imageReceiver = new ImageReceiver(this.AB, c0260a.uri);
                this.AB.Ay.put(c0260a.uri, imageReceiver);
            }
            imageReceiver.m408c(this.AD);
            if (this.AD.AI != 1) {
                this.AB.Ax.put(this.AD, imageReceiver);
            }
            synchronized (ImageManager.Ar) {
                if (!ImageManager.As.contains(c0260a.uri)) {
                    ImageManager.As.add(c0260a.uri);
                    imageReceiver.dN();
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.common.images.ImageManager.e */
    private static final class C0258e implements ComponentCallbacks2 {
        private final C0255b Aw;

        public C0258e(C0255b c0255b) {
            this.Aw = c0255b;
        }

        public void onConfigurationChanged(Configuration newConfig) {
        }

        public void onLowMemory() {
            this.Aw.evictAll();
        }

        public void onTrimMemory(int level) {
            if (level >= 60) {
                this.Aw.evictAll();
            } else if (level >= 20) {
                this.Aw.trimToSize(this.Aw.size() / 2);
            }
        }
    }

    /* renamed from: com.google.android.gms.common.images.ImageManager.f */
    private final class C0259f implements Runnable {
        final /* synthetic */ ImageManager AB;
        private boolean AE;
        private final Bitmap mBitmap;
        private final Uri mUri;
        private final CountDownLatch zf;

        public C0259f(ImageManager imageManager, Uri uri, Bitmap bitmap, boolean z, CountDownLatch countDownLatch) {
            this.AB = imageManager;
            this.mUri = uri;
            this.mBitmap = bitmap;
            this.AE = z;
            this.zf = countDownLatch;
        }

        private void m415a(ImageReceiver imageReceiver, boolean z) {
            imageReceiver.AA = true;
            ArrayList a = imageReceiver.Az;
            int size = a.size();
            for (int i = 0; i < size; i++) {
                C0261a c0261a = (C0261a) a.get(i);
                if (z) {
                    c0261a.m435a(this.AB.mContext, this.mBitmap, false);
                } else {
                    c0261a.m438b(this.AB.mContext, false);
                }
                if (c0261a.AI != 1) {
                    this.AB.Ax.remove(c0261a);
                }
            }
            imageReceiver.AA = false;
        }

        public void run() {
            ed.ac("OnBitmapLoadedRunnable must be executed in the main thread");
            boolean z = this.mBitmap != null;
            if (this.AB.Aw != null) {
                if (this.AE) {
                    this.AB.Aw.evictAll();
                    System.gc();
                    this.AE = false;
                    this.AB.mHandler.post(this);
                    return;
                } else if (z) {
                    this.AB.Aw.put(new C0260a(this.mUri), this.mBitmap);
                }
            }
            ImageReceiver imageReceiver = (ImageReceiver) this.AB.Ay.remove(this.mUri);
            if (imageReceiver != null) {
                m415a(imageReceiver, z);
            }
            this.zf.countDown();
            synchronized (ImageManager.Ar) {
                ImageManager.As.remove(this.mUri);
            }
        }
    }

    static {
        Ar = new Object();
        As = new HashSet();
    }

    private ImageManager(Context context, boolean withMemoryCache) {
        this.mContext = context.getApplicationContext();
        this.mHandler = new Handler(Looper.getMainLooper());
        this.Av = Executors.newFixedThreadPool(4);
        if (withMemoryCache) {
            this.Aw = new C0255b(this.mContext);
            if (fr.eM()) {
                dL();
            }
        } else {
            this.Aw = null;
        }
        this.Ax = new HashMap();
        this.Ay = new HashMap();
    }

    private Bitmap m418a(C0260a c0260a) {
        return this.Aw == null ? null : (Bitmap) this.Aw.get(c0260a);
    }

    public static ImageManager m419a(Context context, boolean z) {
        if (z) {
            if (Au == null) {
                Au = new ImageManager(context, true);
            }
            return Au;
        }
        if (At == null) {
            At = new ImageManager(context, false);
        }
        return At;
    }

    private boolean m422b(C0261a c0261a) {
        ed.ac("ImageManager.cleanupHashMaps() must be called in the main thread");
        if (c0261a.AI == 1) {
            return true;
        }
        ImageReceiver imageReceiver = (ImageReceiver) this.Ax.get(c0261a);
        if (imageReceiver == null) {
            return true;
        }
        if (imageReceiver.AA) {
            return false;
        }
        this.Ax.remove(c0261a);
        imageReceiver.m409d(c0261a);
        return true;
    }

    public static ImageManager create(Context context) {
        return m419a(context, false);
    }

    private void dL() {
        this.mContext.registerComponentCallbacks(new C0258e(this.Aw));
    }

    public void m427a(C0261a c0261a) {
        ed.ac("ImageManager.loadImage() must be called in the main thread");
        boolean b = m422b(c0261a);
        Runnable c0257d = new C0257d(this, c0261a);
        if (b) {
            c0257d.run();
        } else {
            this.mHandler.post(c0257d);
        }
    }

    public void loadImage(ImageView imageView, int resId) {
        C0261a c0261a = new C0261a(resId);
        c0261a.m436a(imageView);
        m427a(c0261a);
    }

    public void loadImage(ImageView imageView, Uri uri) {
        C0261a c0261a = new C0261a(uri);
        c0261a.m436a(imageView);
        m427a(c0261a);
    }

    public void loadImage(ImageView imageView, Uri uri, int defaultResId) {
        C0261a c0261a = new C0261a(uri);
        c0261a.m434L(defaultResId);
        c0261a.m436a(imageView);
        m427a(c0261a);
    }

    public void loadImage(OnImageLoadedListener listener, Uri uri) {
        C0261a c0261a = new C0261a(uri);
        c0261a.m437a(listener);
        m427a(c0261a);
    }

    public void loadImage(OnImageLoadedListener listener, Uri uri, int defaultResId) {
        C0261a c0261a = new C0261a(uri);
        c0261a.m434L(defaultResId);
        c0261a.m437a(listener);
        m427a(c0261a);
    }
}
