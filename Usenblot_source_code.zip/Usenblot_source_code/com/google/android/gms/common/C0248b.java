package com.google.android.gms.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.FragmentManager;
import com.google.android.gms.internal.er;

/* renamed from: com.google.android.gms.common.b */
public class C0248b extends DialogFragment {
    private Dialog mDialog;
    private OnCancelListener yK;

    public C0248b() {
        this.mDialog = null;
        this.yK = null;
    }

    public static C0248b m392a(Dialog dialog, OnCancelListener onCancelListener) {
        C0248b c0248b = new C0248b();
        Dialog dialog2 = (Dialog) er.m1549b((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0248b.mDialog = dialog2;
        if (onCancelListener != null) {
            c0248b.yK = onCancelListener;
        }
        return c0248b;
    }

    public void onCancel(DialogInterface dialog) {
        if (this.yK != null) {
            this.yK.onCancel(dialog);
        }
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return this.mDialog;
    }

    public void show(FragmentManager manager, String tag) {
        super.show(manager, tag);
    }
}
