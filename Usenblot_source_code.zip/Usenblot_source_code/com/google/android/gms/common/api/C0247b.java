package com.google.android.gms.common.api;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api.C0179b;
import com.google.android.gms.common.api.Api.C0236a;
import com.google.android.gms.common.api.C0239a.C0184a;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.ei;
import com.google.android.gms.internal.ei.C0243b;
import com.google.android.gms.internal.er;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/* renamed from: com.google.android.gms.common.api.b */
final class C0247b implements GoogleApiClient {
    private int zA;
    private int zB;
    private int zC;
    private boolean zD;
    private int zE;
    private long zF;
    final Handler zG;
    private final Bundle zH;
    private final Map<C0179b<?>, C0236a> zI;
    private boolean zJ;
    final Set<C0183c> zK;
    final ConnectionCallbacks zL;
    private final C0243b zM;
    private final C0240a zm;
    private final Lock zv;
    private final Condition zw;
    private final ei zx;
    final Queue<C0183c<?>> zy;
    private ConnectionResult zz;

    /* renamed from: com.google.android.gms.common.api.b.c */
    interface C0183c<A extends C0236a> {
        void m197a(C0240a c0240a);

        void m198b(A a) throws DeadObjectException;

        C0179b<A> dp();

        int dr();

        void du();
    }

    /* renamed from: com.google.android.gms.common.api.b.a */
    interface C0240a {
        void m372b(C0183c c0183c);
    }

    /* renamed from: com.google.android.gms.common.api.b.1 */
    class C02411 implements C0240a {
        final /* synthetic */ C0247b zN;

        C02411(C0247b c0247b) {
            this.zN = c0247b;
        }

        public void m373b(C0183c c0183c) {
            this.zN.zv.lock();
            try {
                this.zN.zK.remove(c0183c);
            } finally {
                this.zN.zv.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.common.api.b.2 */
    class C02422 implements ConnectionCallbacks {
        final /* synthetic */ C0247b zN;

        C02422(C0247b c0247b) {
            this.zN = c0247b;
        }

        public void onConnected(Bundle connectionHint) {
            this.zN.zv.lock();
            try {
                if (this.zN.zB == 1) {
                    if (connectionHint != null) {
                        this.zN.zH.putAll(connectionHint);
                    }
                    this.zN.dy();
                }
                this.zN.zv.unlock();
            } catch (Throwable th) {
                this.zN.zv.unlock();
            }
        }

        public void onConnectionSuspended(int cause) {
            this.zN.zv.lock();
            try {
                this.zN.m374G(cause);
                switch (cause) {
                    case Base64Encoder.NO_PADDING /*1*/:
                        if (!this.zN.dA()) {
                            this.zN.zC = 2;
                            this.zN.zG.sendMessageDelayed(this.zN.zG.obtainMessage(1), this.zN.zF);
                            break;
                        }
                        this.zN.zv.unlock();
                        return;
                    case Base64Encoder.URL_SAFE /*2*/:
                        this.zN.connect();
                        break;
                }
                this.zN.zv.unlock();
            } catch (Throwable th) {
                this.zN.zv.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.common.api.b.3 */
    class C02443 implements C0243b {
        final /* synthetic */ C0247b zN;

        C02443(C0247b c0247b) {
            this.zN = c0247b;
        }

        public Bundle cY() {
            return null;
        }

        public boolean dC() {
            return this.zN.zJ;
        }

        public boolean isConnected() {
            return this.zN.isConnected();
        }
    }

    /* renamed from: com.google.android.gms.common.api.b.4 */
    class C02454 implements OnConnectionFailedListener {
        final /* synthetic */ C0247b zN;
        final /* synthetic */ C0179b zO;

        C02454(C0247b c0247b, C0179b c0179b) {
            this.zN = c0247b;
            this.zO = c0179b;
        }

        public void onConnectionFailed(ConnectionResult result) {
            this.zN.zv.lock();
            try {
                if (this.zN.zz == null || this.zO.getPriority() < this.zN.zA) {
                    this.zN.zz = result;
                    this.zN.zA = this.zO.getPriority();
                }
                this.zN.dy();
            } finally {
                this.zN.zv.unlock();
            }
        }
    }

    /* renamed from: com.google.android.gms.common.api.b.b */
    class C0246b extends Handler {
        final /* synthetic */ C0247b zN;

        C0246b(C0247b c0247b, Looper looper) {
            this.zN = c0247b;
            super(looper);
        }

        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                this.zN.zv.lock();
                try {
                    if (!(this.zN.isConnected() || this.zN.isConnecting())) {
                        this.zN.connect();
                    }
                    this.zN.zv.unlock();
                } catch (Throwable th) {
                    this.zN.zv.unlock();
                }
            } else {
                Log.wtf("GoogleApiClientImpl", "Don't know how to handle this message.");
            }
        }
    }

    public C0247b(Context context, Looper looper, ee eeVar, Map<Api, ApiOptions> map, Set<ConnectionCallbacks> set, Set<OnConnectionFailedListener> set2) {
        this.zv = new ReentrantLock();
        this.zw = this.zv.newCondition();
        this.zy = new LinkedList();
        this.zB = 4;
        this.zC = 0;
        this.zD = false;
        this.zF = 5000;
        this.zH = new Bundle();
        this.zI = new HashMap();
        this.zK = new HashSet();
        this.zm = new C02411(this);
        this.zL = new C02422(this);
        this.zM = new C02443(this);
        this.zx = new ei(context, looper, this.zM);
        this.zG = new C0246b(this, looper);
        for (ConnectionCallbacks registerConnectionCallbacks : set) {
            this.zx.registerConnectionCallbacks(registerConnectionCallbacks);
        }
        for (OnConnectionFailedListener registerConnectionFailedListener : set2) {
            this.zx.registerConnectionFailedListener(registerConnectionFailedListener);
        }
        for (Api api : map.keySet()) {
            C0179b dp = api.dp();
            ApiOptions apiOptions = (ApiOptions) map.get(api);
            this.zI.put(dp, dp.m193b(context, looper, eeVar, apiOptions, this.zL, new C02454(this, dp)));
        }
    }

    private void m374G(int i) {
        this.zv.lock();
        try {
            if (this.zB != 3) {
                if (i == -1) {
                    if (isConnecting()) {
                        Iterator it = this.zy.iterator();
                        while (it.hasNext()) {
                            if (((C0183c) it.next()).dr() != 1) {
                                it.remove();
                            }
                        }
                    } else {
                        this.zy.clear();
                    }
                    if (this.zz == null && !this.zy.isEmpty()) {
                        this.zD = true;
                        return;
                    }
                }
                boolean isConnecting = isConnecting();
                boolean isConnected = isConnected();
                this.zB = 3;
                if (isConnecting) {
                    if (i == -1) {
                        this.zz = null;
                    }
                    this.zw.signalAll();
                }
                for (C0183c du : this.zK) {
                    du.du();
                }
                this.zK.clear();
                this.zJ = false;
                for (C0236a c0236a : this.zI.values()) {
                    if (c0236a.isConnected()) {
                        c0236a.disconnect();
                    }
                }
                this.zJ = true;
                this.zB = 4;
                if (isConnected) {
                    if (i != -1) {
                        this.zx.m1469P(i);
                    }
                    this.zJ = false;
                }
            }
            this.zv.unlock();
        } finally {
            this.zv.unlock();
        }
    }

    private <A extends C0236a> void m377a(C0183c<A> c0183c) throws DeadObjectException {
        this.zv.lock();
        try {
            er.m1547a(isConnected(), "GoogleApiClient is not connected yet.");
            er.m1547a(c0183c.dp() != null, "This task can not be executed or enqueued (it's probably a Batch or malformed)");
            if (c0183c instanceof Releasable) {
                this.zK.add(c0183c);
                c0183c.m197a(this.zm);
            }
            c0183c.m198b(m389a(c0183c.dp()));
        } finally {
            this.zv.unlock();
        }
    }

    private boolean dA() {
        this.zv.lock();
        try {
            boolean z = this.zC != 0;
            this.zv.unlock();
            return z;
        } catch (Throwable th) {
            this.zv.unlock();
        }
    }

    private void dB() {
        this.zv.lock();
        try {
            this.zC = 0;
            this.zG.removeMessages(1);
        } finally {
            this.zv.unlock();
        }
    }

    private void dy() {
        this.zv.lock();
        try {
            this.zE--;
            if (this.zE == 0) {
                if (this.zz != null) {
                    this.zD = false;
                    m374G(3);
                    if (dA()) {
                        this.zC--;
                    }
                    if (dA()) {
                        this.zG.sendMessageDelayed(this.zG.obtainMessage(1), this.zF);
                    } else {
                        this.zx.m1470a(this.zz);
                    }
                    this.zJ = false;
                } else {
                    this.zB = 2;
                    dB();
                    this.zw.signalAll();
                    dz();
                    if (this.zD) {
                        this.zD = false;
                        m374G(-1);
                    } else {
                        this.zx.m1471b(this.zH.isEmpty() ? null : this.zH);
                    }
                }
            }
            this.zv.unlock();
        } catch (Throwable th) {
            this.zv.unlock();
        }
    }

    private void dz() {
        er.m1547a(isConnected(), "GoogleApiClient is not connected yet.");
        this.zv.lock();
        while (!this.zy.isEmpty()) {
            try {
                m377a((C0183c) this.zy.remove());
            } catch (Throwable e) {
                Log.w("GoogleApiClientImpl", "Service died while flushing queue", e);
            } catch (Throwable th) {
                this.zv.unlock();
            }
        }
        this.zv.unlock();
    }

    public <C extends C0236a> C m389a(C0179b<C> c0179b) {
        Object obj = (C0236a) this.zI.get(c0179b);
        er.m1549b(obj, (Object) "Appropriate Api was not requested.");
        return obj;
    }

    public <A extends C0236a, T extends C0184a<? extends Result, A>> T m390a(T t) {
        this.zv.lock();
        try {
            if (isConnected()) {
                m391b((C0184a) t);
            } else {
                this.zy.add(t);
            }
            this.zv.unlock();
            return t;
        } catch (Throwable th) {
            this.zv.unlock();
        }
    }

    public <A extends C0236a, T extends C0184a<? extends Result, A>> T m391b(T t) {
        er.m1547a(isConnected(), "GoogleApiClient is not connected yet.");
        dz();
        try {
            m377a((C0183c) t);
        } catch (DeadObjectException e) {
            m374G(1);
        }
        return t;
    }

    public ConnectionResult blockingConnect(long timeout, TimeUnit unit) {
        ConnectionResult connectionResult;
        er.m1547a(Looper.myLooper() != Looper.getMainLooper(), "blockingConnect must not be called on the UI thread");
        this.zv.lock();
        try {
            connect();
            long toNanos = unit.toNanos(timeout);
            while (isConnecting()) {
                toNanos = this.zw.awaitNanos(toNanos);
                if (toNanos <= 0) {
                    connectionResult = new ConnectionResult(14, null);
                    break;
                }
            }
            if (isConnected()) {
                connectionResult = ConnectionResult.yI;
                this.zv.unlock();
            } else if (this.zz != null) {
                connectionResult = this.zz;
                this.zv.unlock();
            } else {
                connectionResult = new ConnectionResult(13, null);
                this.zv.unlock();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            connectionResult = new ConnectionResult(15, null);
        } finally {
            this.zv.unlock();
        }
        return connectionResult;
    }

    public void connect() {
        this.zv.lock();
        try {
            this.zD = false;
            if (isConnected() || isConnecting()) {
                this.zv.unlock();
                return;
            }
            this.zJ = true;
            this.zz = null;
            this.zB = 1;
            this.zH.clear();
            this.zE = this.zI.size();
            for (C0236a connect : this.zI.values()) {
                connect.connect();
            }
            this.zv.unlock();
        } catch (Throwable th) {
            this.zv.unlock();
        }
    }

    public void disconnect() {
        dB();
        m374G(-1);
    }

    public boolean isConnected() {
        this.zv.lock();
        try {
            boolean z = this.zB == 2;
            this.zv.unlock();
            return z;
        } catch (Throwable th) {
            this.zv.unlock();
        }
    }

    public boolean isConnecting() {
        boolean z = true;
        this.zv.lock();
        try {
            if (this.zB != 1) {
                z = false;
            }
            this.zv.unlock();
            return z;
        } catch (Throwable th) {
            this.zv.unlock();
        }
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks listener) {
        return this.zx.isConnectionCallbacksRegistered(listener);
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener listener) {
        return this.zx.isConnectionFailedListenerRegistered(listener);
    }

    public void reconnect() {
        disconnect();
        connect();
    }

    public void registerConnectionCallbacks(ConnectionCallbacks listener) {
        this.zx.registerConnectionCallbacks(listener);
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener listener) {
        this.zx.registerConnectionFailedListener(listener);
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks listener) {
        this.zx.unregisterConnectionCallbacks(listener);
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener listener) {
        this.zx.unregisterConnectionFailedListener(listener);
    }
}
