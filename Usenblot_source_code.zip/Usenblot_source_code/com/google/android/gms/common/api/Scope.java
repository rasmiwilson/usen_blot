package com.google.android.gms.common.api;

public final class Scope {
    private final String zP;

    public Scope(String scopeUri) {
        this.zP = scopeUri;
    }

    public String dD() {
        return this.zP;
    }
}
