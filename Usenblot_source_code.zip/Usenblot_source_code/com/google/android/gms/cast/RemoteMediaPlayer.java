package com.google.android.gms.cast;

import com.google.android.gms.cast.Cast.C0203a;
import com.google.android.gms.cast.Cast.MessageReceivedCallback;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.internal.dq;
import com.google.android.gms.internal.dv;
import com.google.android.gms.internal.dw;
import com.google.android.gms.internal.dx;
import java.io.IOException;
import org.json.JSONObject;

public class RemoteMediaPlayer implements MessageReceivedCallback {
    public static final int RESUME_STATE_PAUSE = 2;
    public static final int RESUME_STATE_PLAY = 1;
    public static final int RESUME_STATE_UNCHANGED = 0;
    public static final int STATUS_CANCELED = 2;
    public static final int STATUS_FAILED = 1;
    public static final int STATUS_REPLACED = 4;
    public static final int STATUS_SUCCEEDED = 0;
    public static final int STATUS_TIMED_OUT = 3;
    private final Object mg;
    private final dv xg;
    private final C0229a xh;
    private OnMetadataUpdatedListener xi;
    private OnStatusUpdatedListener xj;

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.1 */
    class C02181 extends dv {
        final /* synthetic */ RemoteMediaPlayer xk;

        C02181(RemoteMediaPlayer remoteMediaPlayer) {
            this.xk = remoteMediaPlayer;
        }

        protected void onMetadataUpdated() {
            this.xk.onMetadataUpdated();
        }

        protected void onStatusUpdated() {
            this.xk.onStatusUpdated();
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b */
    private static abstract class C0219b extends C0203a<MediaChannelResult> {
        dx xy;

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b.1 */
        class C02301 implements dx {
            final /* synthetic */ C0219b xz;

            C02301(C0219b c0219b) {
                this.xz = c0219b;
            }

            public void m332a(long j, int i, JSONObject jSONObject) {
                this.xz.m201a(new C0232c(new Status(i), jSONObject));
            }

            public void m333k(long j) {
                this.xz.m201a(this.xz.m309j(new Status(RemoteMediaPlayer.STATUS_REPLACED)));
            }
        }

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.b.2 */
        class C02312 implements MediaChannelResult {
            final /* synthetic */ Status vb;
            final /* synthetic */ C0219b xz;

            C02312(C0219b c0219b, Status status) {
                this.xz = c0219b;
                this.vb = status;
            }

            public Status getStatus() {
                return this.vb;
            }
        }

        C0219b() {
            this.xy = new C02301(this);
        }

        public /* synthetic */ Result m308d(Status status) {
            return m309j(status);
        }

        public MediaChannelResult m309j(Status status) {
            return new C02312(this, status);
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.2 */
    class C02202 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ MediaInfo xm;
        final /* synthetic */ boolean xn;
        final /* synthetic */ long xo;
        final /* synthetic */ JSONObject xp;

        C02202(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, MediaInfo mediaInfo, boolean z, long j, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xm = mediaInfo;
            this.xn = z;
            this.xo = j;
            this.xp = jSONObject;
        }

        protected void m311a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m302a(this.xy, this.xm, this.xn, this.xo, this.xp);
                } catch (IOException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.3 */
    class C02213 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ JSONObject xp;

        C02213(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xp = jSONObject;
        }

        protected void m313a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m303a(this.xy, this.xp);
                } catch (IOException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.4 */
    class C02224 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ JSONObject xp;

        C02224(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xp = jSONObject;
        }

        protected void m315a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m306b(this.xy, this.xp);
                } catch (IOException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.5 */
    class C02235 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ JSONObject xp;

        C02235(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xp = jSONObject;
        }

        protected void m317a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m307c(this.xy, this.xp);
                } catch (IOException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.6 */
    class C02246 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ JSONObject xp;
        final /* synthetic */ long xq;
        final /* synthetic */ int xr;

        C02246(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, long j, int i, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xq = j;
            this.xr = i;
            this.xp = jSONObject;
        }

        protected void m319a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m301a(this.xy, this.xq, this.xr, this.xp);
                } catch (IOException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.7 */
    class C02257 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ JSONObject xp;
        final /* synthetic */ double xs;

        C02257(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, double d, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xs = d;
            this.xp = jSONObject;
        }

        protected void m321a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m300a(this.xy, this.xs, this.xp);
                } catch (IllegalStateException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } catch (IllegalArgumentException e2) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } catch (IOException e3) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.8 */
    class C02268 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;
        final /* synthetic */ JSONObject xp;
        final /* synthetic */ boolean xt;

        C02268(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient, boolean z, JSONObject jSONObject) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
            this.xt = z;
            this.xp = jSONObject;
        }

        protected void m323a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m304a(this.xy, this.xt, this.xp);
                } catch (IllegalStateException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } catch (IOException e2) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.9 */
    class C02279 extends C0219b {
        final /* synthetic */ RemoteMediaPlayer xk;
        final /* synthetic */ GoogleApiClient xl;

        C02279(RemoteMediaPlayer remoteMediaPlayer, GoogleApiClient googleApiClient) {
            this.xk = remoteMediaPlayer;
            this.xl = googleApiClient;
        }

        protected void m325a(dq dqVar) {
            synchronized (this.xk.mg) {
                this.xk.xh.m329b(this.xl);
                try {
                    this.xk.xg.m299a(this.xy);
                } catch (IOException e) {
                    m201a(m309j(new Status(RemoteMediaPlayer.STATUS_FAILED)));
                } finally {
                    this.xk.xh.m329b(null);
                }
            }
        }
    }

    public interface MediaChannelResult extends Result {
    }

    public interface OnMetadataUpdatedListener {
        void onMetadataUpdated();
    }

    public interface OnStatusUpdatedListener {
        void onStatusUpdated();
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.a */
    private class C0229a implements dw {
        final /* synthetic */ RemoteMediaPlayer xk;
        private GoogleApiClient xu;
        private long xv;

        /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.a.a */
        private final class C0228a implements ResultCallback<Status> {
            private final long xw;
            final /* synthetic */ C0229a xx;

            C0228a(C0229a c0229a, long j) {
                this.xx = c0229a;
                this.xw = j;
            }

            public void m326i(Status status) {
                if (!status.isSuccess()) {
                    this.xx.xk.xg.m305a(this.xw, status.getStatusCode());
                }
            }

            public /* synthetic */ void onResult(Result x0) {
                m326i((Status) x0);
            }
        }

        public C0229a(RemoteMediaPlayer remoteMediaPlayer) {
            this.xk = remoteMediaPlayer;
            this.xv = 0;
        }

        public void m328a(String str, String str2, long j, String str3) throws IOException {
            if (this.xu == null) {
                throw new IOException("No GoogleApiClient available");
            }
            Cast.CastApi.sendMessage(this.xu, str, str2).setResultCallback(new C0228a(this, j));
        }

        public void m329b(GoogleApiClient googleApiClient) {
            this.xu = googleApiClient;
        }

        public long cV() {
            long j = this.xv + 1;
            this.xv = j;
            return j;
        }
    }

    /* renamed from: com.google.android.gms.cast.RemoteMediaPlayer.c */
    private static final class C0232c implements MediaChannelResult {
        private final Status vl;
        private final JSONObject wP;

        C0232c(Status status, JSONObject jSONObject) {
            this.vl = status;
            this.wP = jSONObject;
        }

        public Status getStatus() {
            return this.vl;
        }
    }

    public RemoteMediaPlayer() {
        this.mg = new Object();
        this.xh = new C0229a(this);
        this.xg = new C02181(this);
        this.xg.m284a(this.xh);
    }

    private void onMetadataUpdated() {
        if (this.xi != null) {
            this.xi.onMetadataUpdated();
        }
    }

    private void onStatusUpdated() {
        if (this.xj != null) {
            this.xj.onStatusUpdated();
        }
    }

    public long getApproximateStreamPosition() {
        long approximateStreamPosition;
        synchronized (this.mg) {
            approximateStreamPosition = this.xg.getApproximateStreamPosition();
        }
        return approximateStreamPosition;
    }

    public MediaInfo getMediaInfo() {
        MediaInfo mediaInfo;
        synchronized (this.mg) {
            mediaInfo = this.xg.getMediaInfo();
        }
        return mediaInfo;
    }

    public MediaStatus getMediaStatus() {
        MediaStatus mediaStatus;
        synchronized (this.mg) {
            mediaStatus = this.xg.getMediaStatus();
        }
        return mediaStatus;
    }

    public String getNamespace() {
        return this.xg.getNamespace();
    }

    public long getStreamDuration() {
        long streamDuration;
        synchronized (this.mg) {
            streamDuration = this.xg.getStreamDuration();
        }
        return streamDuration;
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo) {
        return load(apiClient, mediaInfo, true, 0, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay) {
        return load(apiClient, mediaInfo, autoplay, 0, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition) {
        return load(apiClient, mediaInfo, autoplay, playPosition, null);
    }

    public PendingResult<MediaChannelResult> load(GoogleApiClient apiClient, MediaInfo mediaInfo, boolean autoplay, long playPosition, JSONObject customData) {
        return apiClient.m366b(new C02202(this, apiClient, mediaInfo, autoplay, playPosition, customData));
    }

    public void onMessageReceived(CastDevice castDevice, String namespace, String message) {
        this.xg.m298P(message);
    }

    public PendingResult<MediaChannelResult> pause(GoogleApiClient apiClient) {
        return pause(apiClient, null);
    }

    public PendingResult<MediaChannelResult> pause(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m366b(new C02213(this, apiClient, customData));
    }

    public PendingResult<MediaChannelResult> play(GoogleApiClient apiClient) {
        return play(apiClient, null);
    }

    public PendingResult<MediaChannelResult> play(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m366b(new C02235(this, apiClient, customData));
    }

    public PendingResult<MediaChannelResult> requestStatus(GoogleApiClient apiClient) {
        return apiClient.m366b(new C02279(this, apiClient));
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position) {
        return seek(apiClient, position, STATUS_SUCCEEDED, null);
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position, int resumeState) {
        return seek(apiClient, position, resumeState, null);
    }

    public PendingResult<MediaChannelResult> seek(GoogleApiClient apiClient, long position, int resumeState, JSONObject customData) {
        return apiClient.m366b(new C02246(this, apiClient, position, resumeState, customData));
    }

    public void setOnMetadataUpdatedListener(OnMetadataUpdatedListener listener) {
        this.xi = listener;
    }

    public void setOnStatusUpdatedListener(OnStatusUpdatedListener listener) {
        this.xj = listener;
    }

    public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient apiClient, boolean muteState) {
        return setStreamMute(apiClient, muteState, null);
    }

    public PendingResult<MediaChannelResult> setStreamMute(GoogleApiClient apiClient, boolean muteState, JSONObject customData) {
        return apiClient.m366b(new C02268(this, apiClient, muteState, customData));
    }

    public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient apiClient, double volume) throws IllegalArgumentException {
        return setStreamVolume(apiClient, volume, null);
    }

    public PendingResult<MediaChannelResult> setStreamVolume(GoogleApiClient apiClient, double volume, JSONObject customData) throws IllegalArgumentException {
        if (!Double.isInfinite(volume) && !Double.isNaN(volume)) {
            return apiClient.m366b(new C02257(this, apiClient, volume, customData));
        }
        throw new IllegalArgumentException("Volume cannot be " + volume);
    }

    public PendingResult<MediaChannelResult> stop(GoogleApiClient apiClient) {
        return stop(apiClient, null);
    }

    public PendingResult<MediaChannelResult> stop(GoogleApiClient apiClient, JSONObject customData) {
        return apiClient.m366b(new C02224(this, apiClient, customData));
    }
}
