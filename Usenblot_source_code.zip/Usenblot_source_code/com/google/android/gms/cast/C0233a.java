package com.google.android.gms.cast;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.images.WebImage;
import com.google.android.gms.common.internal.safeparcel.C0264a;
import com.google.android.gms.common.internal.safeparcel.C0264a.C0263a;
import com.google.android.gms.common.internal.safeparcel.C0265b;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;
import java.util.List;

/* renamed from: com.google.android.gms.cast.a */
public class C0233a implements Creator<ApplicationMetadata> {
    static void m339a(ApplicationMetadata applicationMetadata, Parcel parcel, int i) {
        int p = C0265b.m503p(parcel);
        C0265b.m501c(parcel, 1, applicationMetadata.getVersionCode());
        C0265b.m491a(parcel, 2, applicationMetadata.getApplicationId(), false);
        C0265b.m491a(parcel, 3, applicationMetadata.getName(), false);
        C0265b.m500b(parcel, 4, applicationMetadata.getImages(), false);
        C0265b.m492a(parcel, 5, applicationMetadata.wm, false);
        C0265b.m491a(parcel, 6, applicationMetadata.getSenderAppIdentifier(), false);
        C0265b.m489a(parcel, 7, applicationMetadata.cR(), i, false);
        C0265b.m481D(parcel, p);
    }

    public /* synthetic */ Object createFromParcel(Parcel x0) {
        return m340j(x0);
    }

    public ApplicationMetadata m340j(Parcel parcel) {
        Uri uri = null;
        int o = C0264a.m466o(parcel);
        int i = 0;
        String str = null;
        List list = null;
        List list2 = null;
        String str2 = null;
        String str3 = null;
        while (parcel.dataPosition() < o) {
            int n = C0264a.m464n(parcel);
            switch (C0264a.m444S(n)) {
                case Base64Encoder.NO_PADDING /*1*/:
                    i = C0264a.m457g(parcel, n);
                    break;
                case Base64Encoder.URL_SAFE /*2*/:
                    str3 = C0264a.m463m(parcel, n);
                    break;
                case Error.BAD_CVC /*3*/:
                    str2 = C0264a.m463m(parcel, n);
                    break;
                case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
                    list2 = C0264a.m452c(parcel, n, WebImage.CREATOR);
                    break;
                case Error.DECLINED /*5*/:
                    list = C0264a.m477y(parcel, n);
                    break;
                case Error.OTHER /*6*/:
                    str = C0264a.m463m(parcel, n);
                    break;
                case Error.AVS_DECLINE /*7*/:
                    uri = (Uri) C0264a.m446a(parcel, n, Uri.CREATOR);
                    break;
                default:
                    C0264a.m450b(parcel, n);
                    break;
            }
        }
        if (parcel.dataPosition() == o) {
            return new ApplicationMetadata(i, str3, str2, list2, list, str, uri);
        }
        throw new C0263a("Overread allowed size end=" + o, parcel);
    }

    public /* synthetic */ Object[] newArray(int x0) {
        return m341w(x0);
    }

    public ApplicationMetadata[] m341w(int i) {
        return new ApplicationMetadata[i];
    }
}
