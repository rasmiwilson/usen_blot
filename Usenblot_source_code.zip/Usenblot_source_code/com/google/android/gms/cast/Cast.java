package com.google.android.gms.cast;

import android.content.Context;
import android.os.Looper;
import android.os.RemoteException;
import android.text.TextUtils;
import com.appsgeyser.sdk.configuration.Constants;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.C0179b;
import com.google.android.gms.common.api.Api.C0236a;
import com.google.android.gms.common.api.C0239a.C0182c;
import com.google.android.gms.common.api.C0239a.C0184a;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.ApiOptions;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.internal.dq;
import com.google.android.gms.internal.ee;
import com.google.android.gms.internal.er;
import java.io.IOException;

public final class Cast {
    public static final Api API;
    public static final CastApi CastApi;
    public static final String EXTRA_APP_NO_LONGER_RUNNING = "com.google.android.gms.cast.EXTRA_APP_NO_LONGER_RUNNING";
    public static final int MAX_MESSAGE_LENGTH = 65536;
    public static final int MAX_NAMESPACE_LENGTH = 128;
    static final C0179b<dq> va;

    /* renamed from: com.google.android.gms.cast.Cast.1 */
    static class C02021 implements C0179b<dq> {
        C02021() {
        }

        public /* synthetic */ C0236a m240b(Context context, Looper looper, ee eeVar, ApiOptions apiOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            return m241c(context, looper, eeVar, apiOptions, connectionCallbacks, onConnectionFailedListener);
        }

        public dq m241c(Context context, Looper looper, ee eeVar, ApiOptions apiOptions, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            er.m1549b((Object) apiOptions, (Object) "Setting the API options is required.");
            er.m1550b(apiOptions instanceof CastOptions, (Object) "Must provide valid CastOptions!");
            CastOptions castOptions = (CastOptions) apiOptions;
            return new dq(context, looper, castOptions.wv, (long) castOptions.wx, castOptions.ww, connectionCallbacks, onConnectionFailedListener);
        }

        public int getPriority() {
            return Integer.MAX_VALUE;
        }
    }

    public interface ApplicationConnectionResult extends Result {
        ApplicationMetadata getApplicationMetadata();

        String getApplicationStatus();

        String getSessionId();

        boolean getWasLaunched();
    }

    /* renamed from: com.google.android.gms.cast.Cast.a */
    protected static abstract class C0203a<R extends Result> extends C0184a<R, dq> implements PendingResult<R> {
        public C0203a() {
            super(Cast.va);
        }

        public void m242c(int i, String str) {
            m201a(m205d(new Status(i, str, null)));
        }

        public void m243x(int i) {
            m201a(m205d(new Status(i)));
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.b */
    private static abstract class C0204b extends C0203a<Status> {
        private C0204b() {
        }

        public /* synthetic */ Result m244d(Status status) {
            return m245f(status);
        }

        public Status m245f(Status status) {
            return status;
        }
    }

    /* renamed from: com.google.android.gms.cast.Cast.c */
    private static abstract class C0206c extends C0203a<ApplicationConnectionResult> {

        /* renamed from: com.google.android.gms.cast.Cast.c.1 */
        class C02161 implements ApplicationConnectionResult {
            final /* synthetic */ Status vb;
            final /* synthetic */ C0206c wB;

            C02161(C0206c c0206c, Status status) {
                this.wB = c0206c;
                this.vb = status;
            }

            public ApplicationMetadata getApplicationMetadata() {
                return null;
            }

            public String getApplicationStatus() {
                return null;
            }

            public String getSessionId() {
                return null;
            }

            public Status getStatus() {
                return this.vb;
            }

            public boolean getWasLaunched() {
                return false;
            }
        }

        private C0206c() {
        }

        public /* synthetic */ Result m248d(Status status) {
            return m249h(status);
        }

        public ApplicationConnectionResult m249h(Status status) {
            return new C02161(this, status);
        }
    }

    public interface CastApi {

        /* renamed from: com.google.android.gms.cast.Cast.CastApi.a */
        public static final class C0215a implements CastApi {

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.1 */
            class C02051 extends C0204b {
                final /* synthetic */ String wp;
                final /* synthetic */ String wq;
                final /* synthetic */ C0215a wr;

                C02051(C0215a c0215a, String str, String str2) {
                    this.wr = c0215a;
                    this.wp = str;
                    this.wq = str2;
                    super();
                }

                protected void m247a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1402a(this.wp, this.wq, (C0182c) this);
                    } catch (IllegalArgumentException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    } catch (IllegalStateException e2) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.2 */
            class C02072 extends C0206c {
                final /* synthetic */ C0215a wr;
                final /* synthetic */ String ws;

                C02072(C0215a c0215a, String str) {
                    this.wr = c0215a;
                    this.ws = str;
                    super();
                }

                protected void m251a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1403a(this.ws, false, (C0182c) this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.3 */
            class C02083 extends C0206c {
                final /* synthetic */ C0215a wr;
                final /* synthetic */ String ws;
                final /* synthetic */ boolean wt;

                C02083(C0215a c0215a, String str, boolean z) {
                    this.wr = c0215a;
                    this.ws = str;
                    this.wt = z;
                    super();
                }

                protected void m253a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1403a(this.ws, this.wt, (C0182c) this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.4 */
            class C02094 extends C0206c {
                final /* synthetic */ C0215a wr;
                final /* synthetic */ String ws;
                final /* synthetic */ String wu;

                C02094(C0215a c0215a, String str, String str2) {
                    this.wr = c0215a;
                    this.ws = str;
                    this.wu = str2;
                    super();
                }

                protected void m255a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1404b(this.ws, this.wu, this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.5 */
            class C02105 extends C0206c {
                final /* synthetic */ C0215a wr;
                final /* synthetic */ String ws;

                C02105(C0215a c0215a, String str) {
                    this.wr = c0215a;
                    this.ws = str;
                    super();
                }

                protected void m257a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1404b(this.ws, null, this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.6 */
            class C02116 extends C0206c {
                final /* synthetic */ C0215a wr;

                C02116(C0215a c0215a) {
                    this.wr = c0215a;
                    super();
                }

                protected void m259a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1404b(null, null, this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.7 */
            class C02127 extends C0204b {
                final /* synthetic */ C0215a wr;

                C02127(C0215a c0215a) {
                    this.wr = c0215a;
                    super();
                }

                protected void m261a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1405e((C0182c) this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.8 */
            class C02138 extends C0204b {
                final /* synthetic */ C0215a wr;

                C02138(C0215a c0215a) {
                    this.wr = c0215a;
                    super();
                }

                protected void m263a(dq dqVar) throws RemoteException {
                    try {
                        dqVar.m1401a(Constants.PUBLISHER_NAME, (C0182c) this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            /* renamed from: com.google.android.gms.cast.Cast.CastApi.a.9 */
            class C02149 extends C0204b {
                final /* synthetic */ C0215a wr;
                final /* synthetic */ String wu;

                C02149(C0215a c0215a, String str) {
                    this.wr = c0215a;
                    this.wu = str;
                    super();
                }

                protected void m265a(dq dqVar) throws RemoteException {
                    if (TextUtils.isEmpty(this.wu)) {
                        m242c(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE, "IllegalArgument: sessionId cannot be null or empty");
                        return;
                    }
                    try {
                        dqVar.m1401a(this.wu, (C0182c) this);
                    } catch (IllegalStateException e) {
                        m243x(GamesStatusCodes.STATUS_REQUEST_UPDATE_TOTAL_FAILURE);
                    }
                }
            }

            public ApplicationMetadata getApplicationMetadata(GoogleApiClient client) throws IllegalStateException {
                return ((dq) client.m364a(Cast.va)).getApplicationMetadata();
            }

            public String getApplicationStatus(GoogleApiClient client) throws IllegalStateException {
                return ((dq) client.m364a(Cast.va)).getApplicationStatus();
            }

            public double getVolume(GoogleApiClient client) throws IllegalStateException {
                return ((dq) client.m364a(Cast.va)).da();
            }

            public boolean isMute(GoogleApiClient client) throws IllegalStateException {
                return ((dq) client.m364a(Cast.va)).isMute();
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client) {
                return client.m366b(new C02116(this));
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client, String applicationId) {
                return client.m366b(new C02105(this, applicationId));
            }

            public PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient client, String applicationId, String sessionId) {
                return client.m366b(new C02094(this, applicationId, sessionId));
            }

            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId) {
                return client.m366b(new C02072(this, applicationId));
            }

            public PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient client, String applicationId, boolean relaunchIfRunning) {
                return client.m366b(new C02083(this, applicationId, relaunchIfRunning));
            }

            public PendingResult<Status> leaveApplication(GoogleApiClient client) {
                return client.m366b(new C02127(this));
            }

            public void removeMessageReceivedCallbacks(GoogleApiClient client, String namespace) throws IOException, IllegalArgumentException {
                try {
                    ((dq) client.m364a(Cast.va)).m1396Q(namespace);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void requestStatus(GoogleApiClient client) throws IOException, IllegalStateException {
                try {
                    ((dq) client.m364a(Cast.va)).cZ();
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public PendingResult<Status> sendMessage(GoogleApiClient client, String namespace, String message) {
                return client.m366b(new C02051(this, namespace, message));
            }

            public void setMessageReceivedCallbacks(GoogleApiClient client, String namespace, MessageReceivedCallback callbacks) throws IOException, IllegalStateException {
                try {
                    ((dq) client.m364a(Cast.va)).m1400a(namespace, callbacks);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void setMute(GoogleApiClient client, boolean mute) throws IOException, IllegalStateException {
                try {
                    ((dq) client.m364a(Cast.va)).m1407t(mute);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public void setVolume(GoogleApiClient client, double volume) throws IOException, IllegalArgumentException, IllegalStateException {
                try {
                    ((dq) client.m364a(Cast.va)).m1397a(volume);
                } catch (RemoteException e) {
                    throw new IOException("service error");
                }
            }

            public PendingResult<Status> stopApplication(GoogleApiClient client) {
                return client.m366b(new C02138(this));
            }

            public PendingResult<Status> stopApplication(GoogleApiClient client, String sessionId) {
                return client.m366b(new C02149(this, sessionId));
            }
        }

        ApplicationMetadata getApplicationMetadata(GoogleApiClient googleApiClient) throws IllegalStateException;

        String getApplicationStatus(GoogleApiClient googleApiClient) throws IllegalStateException;

        double getVolume(GoogleApiClient googleApiClient) throws IllegalStateException;

        boolean isMute(GoogleApiClient googleApiClient) throws IllegalStateException;

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient);

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str);

        PendingResult<ApplicationConnectionResult> joinApplication(GoogleApiClient googleApiClient, String str, String str2);

        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str);

        PendingResult<ApplicationConnectionResult> launchApplication(GoogleApiClient googleApiClient, String str, boolean z);

        PendingResult<Status> leaveApplication(GoogleApiClient googleApiClient);

        void removeMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str) throws IOException, IllegalArgumentException;

        void requestStatus(GoogleApiClient googleApiClient) throws IOException, IllegalStateException;

        PendingResult<Status> sendMessage(GoogleApiClient googleApiClient, String str, String str2);

        void setMessageReceivedCallbacks(GoogleApiClient googleApiClient, String str, MessageReceivedCallback messageReceivedCallback) throws IOException, IllegalStateException;

        void setMute(GoogleApiClient googleApiClient, boolean z) throws IOException, IllegalStateException;

        void setVolume(GoogleApiClient googleApiClient, double d) throws IOException, IllegalArgumentException, IllegalStateException;

        PendingResult<Status> stopApplication(GoogleApiClient googleApiClient);

        PendingResult<Status> stopApplication(GoogleApiClient googleApiClient, String str);
    }

    public static final class CastOptions implements ApiOptions {
        final CastDevice wv;
        final Listener ww;
        private final int wx;

        public static final class Builder {
            private int wA;
            CastDevice wy;
            Listener wz;

            private Builder(CastDevice castDevice, Listener castListener) {
                er.m1549b((Object) castDevice, (Object) "CastDevice parameter cannot be null");
                er.m1549b((Object) castListener, (Object) "CastListener parameter cannot be null");
                this.wy = castDevice;
                this.wz = castListener;
                this.wA = 0;
            }

            public CastOptions build() {
                return new CastOptions();
            }

            public Builder setVerboseLoggingEnabled(boolean enabled) {
                if (enabled) {
                    this.wA |= 1;
                } else {
                    this.wA &= -2;
                }
                return this;
            }
        }

        private CastOptions(Builder builder) {
            this.wv = builder.wy;
            this.ww = builder.wz;
            this.wx = builder.wA;
        }

        public static Builder builder(CastDevice castDevice, Listener castListener) {
            return new Builder(castListener, null);
        }
    }

    public static abstract class Listener {
        public void onApplicationDisconnected(int statusCode) {
        }

        public void onApplicationStatusChanged() {
        }

        public void onVolumeChanged() {
        }
    }

    public interface MessageReceivedCallback {
        void onMessageReceived(CastDevice castDevice, String str, String str2);
    }

    static {
        va = new C02021();
        API = new Api(va, new Scope[0]);
        CastApi = new C0215a();
    }

    private Cast() {
    }
}
