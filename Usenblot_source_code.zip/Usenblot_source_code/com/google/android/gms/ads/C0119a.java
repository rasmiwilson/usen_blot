package com.google.android.gms.ads;

/* renamed from: com.google.android.gms.ads.a */
public final class C0119a {
    public static AdSize m21a(int i, int i2, String str) {
        return new AdSize(i, i2, str);
    }
}
