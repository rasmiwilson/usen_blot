package com.google.analytics.tracking.android;

interface Clock {
    long currentTimeMillis();
}
