package com.appsgeyser.player;

import android.util.Log;
import android.webkit.JavascriptInterface;

public class Injector extends BaseSecureJsInterface {

    /* renamed from: com.appsgeyser.player.Injector.1 */
    class C00711 implements Runnable {
        C00711() {
        }

        public void run() {
            UnityPlayerNativeActivity.web.setVisibility(8);
        }
    }

    @JavascriptInterface
    public void close() {
        UnityPlayerNativeActivity.mn.runOnUiThread(new C00711());
    }

    @JavascriptInterface
    public void dismissAdMobOnTimeout(int i) {
    }

    @JavascriptInterface
    public void stayAlive() {
    }

    @JavascriptInterface
    public void showAdMobFullScreenBanner(String adMobFullScreenVarsadUnitID, String adMobFullScreenVarskeywords, String adMobFullScreenVarsgender, String adMobFullScreenVarsbirthday, String latitude, String adMobFullScreenVarslong) {
    }

    @JavascriptInterface
    public void setClickUrl(String url, String hash) {
        if (_checkSecurityCode(hash)) {
            UnityPlayerNativeActivity._clickUrl = url;
            Log.i("sendclick", url);
        }
    }
}
