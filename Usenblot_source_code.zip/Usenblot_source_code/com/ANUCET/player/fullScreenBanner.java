package com.appsgeyser.player;

import android.app.Activity;
import android.util.Log;
import com.appsgeyser.sdk.configuration.Configuration;
import com.appsgeyser.sdk.configuration.Constants;
import com.appsgeyser.sdk.location.Geolocation;

public class fullScreenBanner extends BaseServerClient {
    private static final String BaseURL = "http://splash.appsgeyser.com/";
    private static final String platformVersion = "0.149";

    public String getFullScreenBannerURL() {
        Configuration config = Configuration.getInstance();
        Activity activity = UnityPlayerNativeActivity.mn;
        String version = platformVersion;
        String strUrl = Constants.PUBLISHER_NAME;
        String _appGuid = config.getAppGuid();
        String id = config.getApplicationId();
        double[] coords = Geolocation.getCoords(activity);
        String avid = UnityPlayerNativeActivity.getAVID();
        if (avid == null) {
            strUrl = "?widgetid=" + id + "&guid=" + _appGuid + "&v=" + version + "&hid=" + DeviceIdParser.getDeviceId(activity) + "&aid=" + DeviceIdParser.getAndroidId(activity) + "&tlat=" + coords[0] + "&tlon=" + coords[1] + "&p=android";
        } else {
            String isEnableString;
            if (UnityPlayerNativeActivity.getEnableTracking()) {
                isEnableString = "true";
            } else {
                isEnableString = "false";
            }
            strUrl = "?widgetid=" + id + "&guid=" + _appGuid + "&v=" + version + "&advid=" + avid + "&limit_ad_tracking_enabled=" + isEnableString + "&tlat=" + coords[0] + "&tlon=" + coords[1] + "&p=android";
        }
        Log.d("Unity", "full screen url:http://splash.appsgeyser.com/" + strUrl);
        return new StringBuilder(BaseURL).append(strUrl).toString();
    }

    public String getFullScreenBanner() {
        return SendRequestSync(getFullScreenBannerURL());
    }
}
