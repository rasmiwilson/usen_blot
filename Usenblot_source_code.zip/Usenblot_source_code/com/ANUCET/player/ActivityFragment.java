package com.appsgeyser.player;

import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.LinearLayout;

public class ActivityFragment extends Activity {
    Context ctx;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.ctx = this;
        WebView wb = new WebView(this);
        setContentView(wb);
        wb.loadUrl("http://www.ya.ru");
        Fragment game = new Fragment();
        LinearLayout layout = new LinearLayout(this);
    }
}
