package com.appsgeyser.player;

import com.unity3d.player.UnityPlayer;

public class Bridge {
    public static void SendUnityMessage(String objectName, String methodName, String parametrText) {
        UnityPlayer.UnitySendMessage(objectName, methodName, parametrText);
    }
}
