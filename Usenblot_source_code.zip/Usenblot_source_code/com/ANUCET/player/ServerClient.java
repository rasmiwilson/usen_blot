package com.appsgeyser.player;

public class ServerClient extends BaseServerClient {
    public String sendClick(String url) {
        return SendRequestSync(url);
    }
}
