package com.appsgeyser.player;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.TextView;
import com.appsgeyser.sdk.AppsgeyserSDK;
import com.appsgeyser.sdk.ads.AdView;
import com.appsgeyser.sdk.ads.AdsBannerWebViewClient;
import com.appsgeyser.sdk.ads.AdsBannerWebViewClient.OnPageFinishedListener;
import com.appsgeyser.sdk.ads.AdsBannerWebViewClient.OnPageStartedListener;
import com.appsgeyser.sdk.ads.StatServerClient;
import com.appsgeyser.sdk.configuration.Constants;
import com.google.android.gms.ads.identifier.AdvertisingIdClient;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import java.io.IOException;
import java.io.InputStream;

public class UnityPlayerNativeActivity extends com.unity3d.player.UnityPlayerNativeActivity implements OnPageFinishedListener, OnPageStartedListener {
    public static String _bannerUrl;
    public static String _clickUrl;
    private static StatServerClient _serverClient;
    private static String avid;
    private static boolean isLAT;
    public static UnityPlayerNativeActivity mn;
    public static TextView text;
    public static String url;
    public static WebView web;
    public static String widgetid;

    /* renamed from: com.appsgeyser.player.UnityPlayerNativeActivity.1 */
    class C00721 implements Runnable {
        C00721() {
        }

        public void run() {
            Context ctx = UnityPlayerNativeActivity.this.getApplicationContext();
            try {
                Log.d("Unity", "AdvertisingIdClient");
                Info adInfo = AdvertisingIdClient.getAdvertisingIdInfo(ctx);
                Log.d("Unity", "AdvertisingDone");
                UnityPlayerNativeActivity.avid = adInfo.getId();
                Log.d("Unity", "avid=" + UnityPlayerNativeActivity.avid.toString());
                UnityPlayerNativeActivity.isLAT = adInfo.isLimitAdTrackingEnabled();
                UnityPlayerNativeActivity.this.finished(adInfo);
            } catch (IllegalStateException e) {
                e.printStackTrace();
            } catch (GooglePlayServicesRepairableException e2) {
                e2.printStackTrace();
            } catch (IOException e3) {
                e3.printStackTrace();
            } catch (GooglePlayServicesNotAvailableException e4) {
                e4.printStackTrace();
            }
            UnityPlayerNativeActivity.this.finished(null);
        }
    }

    /* renamed from: com.appsgeyser.player.UnityPlayerNativeActivity.2 */
    class C00732 implements Runnable {
        private final /* synthetic */ Info val$adInfo;

        C00732(Info info) {
            this.val$adInfo = info;
        }

        public void run() {
            UnityPlayerNativeActivity.avid = this.val$adInfo.getId();
            UnityPlayerNativeActivity.isLAT = this.val$adInfo.isLimitAdTrackingEnabled();
            AppsgeyserSDK.sendApiKey(UnityPlayerNativeActivity.mn.getString(UnityPlayerNativeActivity.mn.getResources().getIdentifier("widgetID", "string", UnityPlayerNativeActivity.mn.getPackageName())));
            AppsgeyserSDK.makeBanner();
        }
    }

    static {
        _bannerUrl = "about:blank";
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mn = this;
        _serverClient = new StatServerClient();
        AppsgeyserSDK.application = getApplication();
        AppsgeyserSDK.sendApiKey(mn.getString(mn.getResources().getIdentifier("widgetID", "string", mn.getPackageName())));
        AppsgeyserSDK.makeBanner();
    }

    public static void start_banners() {
        web = new WebView(mn);
        web.setVisibility(8);
        if (AppsgeyserSDK.Apikey != null) {
            Display display = mn.getWindowManager().getDefaultDisplay();
            Point size = new Point();
            if (VERSION.SDK_INT >= 13) {
                display.getSize(size);
            } else {
                size.x = display.getWidth();
                size.y = display.getHeight();
            }
            int x = size.x;
            int y = size.y;
            View currView = mn.getWindow().getDecorView().findViewById(16908290);
            LayoutParams webViewParams = new LayoutParams(700, 200);
            ((FrameLayout) currView).addView(new AdView(mn, null), webViewParams);
            ((FrameLayout) currView).addView(web, new LayoutParams(x, y));
            web.setVisibility(8);
            web.addJavascriptInterface(new Injector(), "AppsgeyserBanner");
            web.getSettings().setJavaScriptEnabled(true);
            web.getSettings().setDomStorageEnabled(true);
            AdsBannerWebViewClient client = new AdsBannerWebViewClient();
            client.setOnPageStartedListener(mn);
            client.setOnPageFinishedListener(mn);
            web.setWebViewClient(client);
            _bannerUrl = new fullScreenBanner().getFullScreenBannerURL();
            web.loadUrl(_bannerUrl);
        }
    }

    protected void onActivityResult(int Req, int res, Intent data) {
        super.onActivityResult(Req, res, data);
    }

    private String getXml(String path) {
        try {
            InputStream is = mn.getAssets().open(path);
            byte[] data = new byte[is.available()];
            is.read(data);
            return new String(data);
        } catch (IOException e1) {
            e1.printStackTrace();
            return null;
        }
    }

    public boolean loadStarted(WebView view, String url, Bitmap favicon) {
        if (url.equals(_bannerUrl) || url.equals("about:blank")) {
            return true;
        }
        view.stopLoading();
        mn.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url.replaceAll("&nostat=1", Constants.PUBLISHER_NAME))));
        if (_clickUrl == null || _clickUrl.length() <= 0) {
            web.setVisibility(8);
        } else {
            _serverClient.sendClickInfo(_clickUrl);
            _clickUrl = null;
        }
        return false;
    }

    public void loadFinished(WebView view, String url) {
        if (_clickUrl == null || _clickUrl.length() <= 0) {
            web.setVisibility(8);
        } else {
            web.setVisibility(0);
        }
    }

    public static void getIdThread() {
        Info adInfo = null;
        try {
            if (mn != null) {
                adInfo = AdvertisingIdClient.getAdvertisingIdInfo(mn);
            }
        } catch (IOException e) {
        } catch (GooglePlayServicesNotAvailableException e2) {
        } catch (IllegalStateException e3) {
            e3.printStackTrace();
        } catch (GooglePlayServicesRepairableException e4) {
            e4.printStackTrace();
        }
        avid = adInfo.getId();
        isLAT = adInfo.isLimitAdTrackingEnabled();
    }

    public static String getAVID() {
        return avid;
    }

    public static boolean getEnableTracking() {
        return isLAT;
    }

    protected void onStart() {
        super.onStart();
        Log.d("Unity", "Starting Analytics activity");
        new Thread(new C00721()).start();
    }

    private void finished(Info adInfo) {
        if (adInfo != null) {
            runOnUiThread(new C00732(adInfo));
        }
    }

    protected void onStop() {
        super.onStop();
        Log.d("Unity", "Stopping Analytics activity");
    }
}
