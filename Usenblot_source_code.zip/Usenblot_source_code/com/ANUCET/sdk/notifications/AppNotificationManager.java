package com.appsgeyser.sdk.notifications;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.view.accessibility.AccessibilityEventCompat;
import com.appsgeyser.sdk.MessageViewer;
import com.google.android.gms.drive.DriveFile;
import com.google.android.gms.plus.PlusShare;

public class AppNotificationManager {
    public static final int NOTIFICATION_ID = 10001;

    public static Intent getLaunchIntent(Context context, String title, String url) {
        Intent intent = new Intent(context, MessageViewer.class);
        intent.addFlags(67108864);
        intent.addFlags(DriveFile.MODE_READ_ONLY);
        intent.addFlags(AccessibilityEventCompat.TYPE_TOUCH_INTERACTION_END);
        Bundle extras = new Bundle();
        extras.putString(PlusShare.KEY_CALL_TO_ACTION_URL, url);
        extras.putString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE, title);
        intent.putExtras(extras);
        return intent;
    }

    public static void generateNotification(Context context, String msg, String title, Intent intent) {
        Notification notification = new Notification(context.getApplicationInfo().icon, title, System.currentTimeMillis());
        notification.setLatestEventInfo(context, title, msg, PendingIntent.getActivity(context, (int) (System.currentTimeMillis() & 268435455), intent, 0));
        notification.flags |= 16;
        ((NotificationManager) context.getSystemService("notification")).notify((int) System.currentTimeMillis(), notification);
        playNotificationSound(context);
    }

    public static void playNotificationSound(Context context) {
        Uri uri = RingtoneManager.getDefaultUri(2);
        if (uri != null) {
            Ringtone rt = RingtoneManager.getRingtone(context, uri);
            if (rt != null) {
                rt.setStreamType(5);
                rt.play();
            }
        }
    }
}
