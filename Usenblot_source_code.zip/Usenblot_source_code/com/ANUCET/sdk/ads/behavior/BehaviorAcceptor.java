package com.appsgeyser.sdk.ads.behavior;

public interface BehaviorAcceptor {
    void acceptBehavior(BehaviorVisitor behaviorVisitor);
}
