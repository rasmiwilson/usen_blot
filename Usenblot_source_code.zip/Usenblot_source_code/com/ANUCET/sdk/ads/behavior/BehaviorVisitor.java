package com.appsgeyser.sdk.ads.behavior;

public interface BehaviorVisitor {
    void visit(BehaviorAcceptor behaviorAcceptor);
}
