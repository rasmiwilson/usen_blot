package com.appsgeyser.sdk.ads;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.webkit.WebView;
import com.appsgeyser.player.UnityPlayerNativeActivity;
import com.appsgeyser.sdk.ads.AdsBannerWebViewClient.OnPageFinishedListener;
import com.appsgeyser.sdk.ads.AdsBannerWebViewClient.OnPageStartedListener;
import com.appsgeyser.sdk.ads.behavior.BehaviorAcceptor;
import com.appsgeyser.sdk.ads.behavior.BehaviorFactory.ClickBehavior;
import com.appsgeyser.sdk.ads.behavior.BehaviorVisitor;
import com.appsgeyser.sdk.ads.behavior.loaderBehaviors.LoaderBehavior;
import com.appsgeyser.sdk.configuration.Configuration;
import com.appsgeyser.sdk.configuration.Constants;
import com.appsgeyser.sdk.device.Device;
import com.appsgeyser.sdk.location.Geolocation;
import com.appsgeyser.sdk.server.ContentRequest;
import com.appsgeyser.sdk.server.ContentRequest.Method;
import com.appsgeyser.sdk.server.Response;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

public class AdsLoader implements OnPageFinishedListener, OnPageStartedListener, BehaviorAcceptor {
    private static final String AD_SERVER_DOMAIN = "http://ads.appsgeyser.com/";
    final float DEFAULT_HIDE_TIMEOUT;
    private AdView _adView;
    private String _bannerUrl;
    private ClickBehavior _clickBehavior;
    private String _clickUrl;
    Thread _closeBannerThread;
    private HeadersReceiver _headersReceiver;
    private AdsLoadingFinishedListener _loadingFinishedListener;
    Timer _refreshTimer;
    private StatServerClient _serverClient;

    public interface AdsLoadingFinishedListener {
        void onAdLoadFinished();
    }

    public interface HeadersReceiver {
        boolean onAdHeadersReceived(Map<String, List<String>> map);
    }

    /* renamed from: com.appsgeyser.sdk.ads.AdsLoader.1 */
    class C00791 implements OnTouchListener {
        C00791() {
        }

        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case Base64Encoder.DEFAULT /*0*/:
                case Base64Encoder.NO_PADDING /*1*/:
                    if (!v.hasFocus()) {
                        v.requestFocus();
                        break;
                    }
                    break;
            }
            return false;
        }
    }

    /* renamed from: com.appsgeyser.sdk.ads.AdsLoader.2 */
    class C00802 extends Thread {
        private final /* synthetic */ AdView val$adView;

        C00802(AdView adView) {
            this.val$adView = adView;
        }

        public void run() {
            AdsLoader.this._refreshTimer.cancel();
            this.val$adView.getBrowser().stopLoading();
            AdsLoader.this._adView.hide();
        }
    }

    /* renamed from: com.appsgeyser.sdk.ads.AdsLoader.3 */
    class C00823 extends Thread {

        /* renamed from: com.appsgeyser.sdk.ads.AdsLoader.3.1 */
        class C00811 implements Runnable {
            C00811() {
            }

            public void run() {
                AdsLoader.this._adView.getBrowser().loadUrl(AdsLoader.this._bannerUrl);
            }
        }

        C00823() {
        }

        public void run() {
            Map<String, List<String>> headers = AdsLoader.this._loadHeaders(AdsLoader.this._bannerUrl);
            if (headers == null) {
                return;
            }
            if (AdsLoader.this._headersReceiver == null || AdsLoader.this._headersReceiver.onAdHeadersReceived(headers)) {
                UnityPlayerNativeActivity.mn.runOnUiThread(new C00811());
            }
        }
    }

    /* renamed from: com.appsgeyser.sdk.ads.AdsLoader.4 */
    class C00834 extends TimerTask {
        C00834() {
        }

        public void run() {
            AdsLoader.this.reload();
            AdsLoader.this._refreshTimer.cancel();
        }
    }

    public AdsLoader() {
        this.DEFAULT_HIDE_TIMEOUT = 60000.0f;
        this._closeBannerThread = null;
        this._refreshTimer = new Timer();
    }

    public void init(AdView adView) {
        this._adView = adView;
        adView.setOnTouchListener(new C00791());
        this._serverClient = new StatServerClient();
        this._bannerUrl = _createBannerUrl();
        this._clickBehavior = ClickBehavior.HIDE;
        this._closeBannerThread = new C00802(adView);
    }

    private String _createBannerUrl() {
        double[] coords = Geolocation.getCoords(this._adView.getContext());
        String deviceId = Constants.PUBLISHER_NAME;
        String androidId = Constants.PUBLISHER_NAME;
        try {
            deviceId = Device.getDeviceId(this._adView.getContext());
            androidId = Device.getAndroidId(this._adView.getContext());
        } catch (Exception e) {
        }
        Configuration configuration = Configuration.getInstance();
        String version = configuration.getPlatformVersion();
        String avid = UnityPlayerNativeActivity.getAVID();
        if (avid == null) {
            String query = "?widgetid=" + configuration.getApplicationId() + "&guid=" + configuration.getAppGuid() + "&v=" + version + "&hid=" + deviceId + "&aid=" + androidId + "&tlat=" + coords[0] + "&tlon=" + coords[1] + "&p=android&sdk=1";
            Log.d("Unity", "bunner url:http://ads.appsgeyser.com/" + query);
            return new StringBuilder(AD_SERVER_DOMAIN).append(query).toString();
        }
        String isEnableString;
        if (UnityPlayerNativeActivity.getEnableTracking()) {
            isEnableString = "true";
        } else {
            isEnableString = "false";
        }
        String strUrl = "?widgetid=" + configuration.getApplicationId() + "&guid=" + configuration.getAppGuid() + "&v=" + version + "advid=" + avid + "&limit_ad_tracking_enabled=" + isEnableString + "&tlat=" + coords[0] + "&tlon=" + coords[1] + "&p=android";
        Log.d("Unity", "bunner url:http://ads.appsgeyser.com/" + strUrl);
        return new StringBuilder(AD_SERVER_DOMAIN).append(strUrl).toString();
    }

    public String getClickUrl() {
        return this._clickUrl;
    }

    public void setClickUrl(String clickUrl) {
        this._clickUrl = clickUrl;
    }

    public void setHeaderReceiver(HeadersReceiver receiver) {
        this._headersReceiver = receiver;
    }

    public void setAdsLoadingFinishedListener(AdsLoadingFinishedListener listener) {
        this._loadingFinishedListener = listener;
    }

    public void reload() {
        try {
            new C00823().start();
        } catch (Exception e) {
            Log.e("AdsLoader", e.getMessage());
        }
    }

    private Map<String, List<String>> _loadHeaders(String url) {
        ContentRequest request = new ContentRequest(new StringBuilder(String.valueOf(url)).append("&test=1").toString());
        request.setMethod(Method.HEAD);
        request.addHeader(ContentRequest.DEFAULT_HEADER_CACHE);
        Response response = request.execute();
        if (response == null || response.status() != 200) {
            return null;
        }
        return response.getHeaders();
    }

    public void changeClickBehavior(ClickBehavior clickBehavior) {
        this._clickBehavior = clickBehavior;
    }

    public void setRefreshTimeout(float seconds) {
        if (((double) seconds) > 0.0d) {
            this._refreshTimer.cancel();
            this._refreshTimer = new Timer();
            this._refreshTimer.scheduleAtFixedRate(new C00834(), (long) ((int) (1000.0f * seconds)), 100);
        }
    }

    public void setHideTimeout(float seconds) {
        if (((double) seconds) <= 0.0d) {
            seconds = 60000.0f;
        }
        this._adView.removeCallbacks(this._closeBannerThread);
        this._adView.postDelayed(this._closeBannerThread, (long) (1000.0f * seconds));
    }

    public void acceptBehavior(BehaviorVisitor visitor) {
        if (visitor instanceof LoaderBehavior) {
            ((LoaderBehavior) visitor).visit((BehaviorAcceptor) this);
        }
    }

    public void loadFinished(WebView view, String url) {
        if (url.equalsIgnoreCase(this._bannerUrl)) {
            _setDefaults();
            if (this._loadingFinishedListener != null) {
                this._loadingFinishedListener.onAdLoadFinished();
            }
        }
    }

    private void _setDefaults() {
        this._adView.show();
        this._refreshTimer.cancel();
        setHideTimeout(60000.0f);
        this._adView.applyDefaultSettings();
    }

    public boolean loadStarted(WebView view, String url, Bitmap favicon) {
        if (url.equals(this._bannerUrl)) {
            return true;
        }
        if (this._clickBehavior == ClickBehavior.HIDE) {
            this._adView.hide();
            this._refreshTimer.cancel();
        } else if (this._clickBehavior == ClickBehavior.REMAIN_ON_SCREEN) {
            reload();
        }
        view.stopLoading();
        this._adView.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url.replaceAll("&nostat=1", Constants.PUBLISHER_NAME))));
        if (this._clickUrl != null && this._clickUrl.length() > 0) {
            this._serverClient.sendClickInfo(this._clickUrl);
        }
        return false;
    }
}
