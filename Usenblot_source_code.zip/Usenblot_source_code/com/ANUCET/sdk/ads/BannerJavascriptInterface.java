package com.appsgeyser.sdk.ads;

import android.webkit.JavascriptInterface;
import com.appsgeyser.sdk.StringUtils;
import com.appsgeyser.sdk.configuration.Configuration;
import com.appsgeyser.sdk.configuration.Constants;
import com.appsgeyser.sdk.device.Device;
import com.appsgeyser.sdk.hasher.Hasher;

public class BannerJavascriptInterface {
    public static String JS_INTERFACE_NAME;
    private AdView _adView;
    private AdsLoader _adsLoader;
    private String _androidId;

    /* renamed from: com.appsgeyser.sdk.ads.BannerJavascriptInterface.1 */
    class C00841 implements Runnable {
        C00841() {
        }

        public void run() {
            try {
                BannerJavascriptInterface.this._androidId = Device.getAndroidId(BannerJavascriptInterface.this._adView.getContext());
            } catch (Exception e) {
                BannerJavascriptInterface.this._androidId = null;
            }
        }
    }

    /* renamed from: com.appsgeyser.sdk.ads.BannerJavascriptInterface.2 */
    class C00852 implements Runnable {
        C00852() {
        }

        public void run() {
            BannerJavascriptInterface.this._adView.hide();
        }
    }

    /* renamed from: com.appsgeyser.sdk.ads.BannerJavascriptInterface.3 */
    class C00863 implements Runnable {
        private final /* synthetic */ String val$hash;
        private final /* synthetic */ String val$url;

        C00863(String str, String str2) {
            this.val$hash = str;
            this.val$url = str2;
        }

        public void run() {
            if (BannerJavascriptInterface.this._checkSecurityCode(this.val$hash)) {
                BannerJavascriptInterface.this._adsLoader.setClickUrl(this.val$url);
            }
        }
    }

    /* renamed from: com.appsgeyser.sdk.ads.BannerJavascriptInterface.4 */
    class C00874 implements Runnable {
        private final /* synthetic */ String val$hash;

        C00874(String str) {
            this.val$hash = str;
        }

        public void run() {
            if (BannerJavascriptInterface.this._checkSecurityCode(this.val$hash)) {
                BannerJavascriptInterface.this._adsLoader.reload();
            }
        }
    }

    static {
        JS_INTERFACE_NAME = "AppsgeyserBanner";
    }

    public BannerJavascriptInterface(AdView adView, AdsLoader loader) {
        this._adView = adView;
        this._adsLoader = loader;
        this._adView.post(new C00841());
    }

    @JavascriptInterface
    public void close() {
        this._adView.post(new C00852());
    }

    @JavascriptInterface
    public void setClickUrl(String url, String hash) {
        this._adView.post(new C00863(hash, url));
    }

    @JavascriptInterface
    public String getAndroidId(String hash) {
        if (_checkSecurityCode(hash)) {
            return this._androidId;
        }
        return Constants.PUBLISHER_NAME;
    }

    @JavascriptInterface
    public void reload(String hash) {
        this._adView.post(new C00874(hash));
    }

    @JavascriptInterface
    protected boolean _checkSecurityCode(String hashCode) {
        Configuration config = Configuration.getInstance();
        String appId = config.getApplicationId();
        String guid = config.getAppGuid();
        if (StringUtils.isNotNullOrEmptyString(appId) && StringUtils.isNotNullOrEmptyString(guid)) {
            return hashCode.equalsIgnoreCase(Hasher.md5(new StringBuilder(String.valueOf(guid)).append(appId).toString()));
        }
        return false;
    }
}
