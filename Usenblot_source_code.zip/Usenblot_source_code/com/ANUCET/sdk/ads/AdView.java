package com.appsgeyser.sdk.ads;

import android.content.Context;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions.Callback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import com.appsgeyser.sdk.ads.behavior.BehaviorAcceptor;
import com.appsgeyser.sdk.ads.behavior.BehaviorVisitor;
import com.appsgeyser.sdk.ads.behavior.bannerBehaviors.AdViewBehavior;

public class AdView extends RelativeLayout implements BehaviorAcceptor {
    private static final int DEFAULT_HEIGHT = 80;
    private static final int DEFAULT_WIDTH = 480;
    private AdsLoader _adsLoader;
    private WebView _browser;
    private AdsBannerWebViewClient _browserClient;
    private DisplayMetrics _displayMetrics;
    private AdsHeaderReceiver _headerReceiver;
    private int _height;
    private int _width;

    /* renamed from: com.appsgeyser.sdk.ads.AdView.1 */
    class C00781 extends WebChromeClient {
        C00781() {
        }

        public void onGeolocationPermissionsShowPrompt(String origin, Callback callback) {
            callback.invoke(origin, true, false);
        }
    }

    public AdView(Context context, AttributeSet attrs) {
        super(context, attrs);
        this._width = DEFAULT_WIDTH;
        this._height = DEFAULT_HEIGHT;
        _init();
    }

    private void _init() {
        setVisibility(8);
        if (getContext().checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0 && getContext().checkCallingOrSelfPermission("android.permission.INTERNET") == 0) {
            this._browser = new WebView(getContext());
            addView(this._browser, new LayoutParams(-1, -1));
            this._adsLoader = new AdsLoader();
            this._adsLoader.init(this);
            this._headerReceiver = new AdsHeaderReceiver(this, this._adsLoader);
            this._adsLoader.setAdsLoadingFinishedListener(this._headerReceiver);
            this._adsLoader.setHeaderReceiver(this._headerReceiver);
            this._browser.addJavascriptInterface(new BannerJavascriptInterface(this, this._adsLoader), BannerJavascriptInterface.JS_INTERFACE_NAME);
            this._browserClient = new AdsBannerWebViewClient();
            this._browserClient.setOnPageFinishedListener(this._adsLoader);
            this._browserClient.setOnPageStartedListener(this._adsLoader);
            this._browser.setWebChromeClient(new C00781());
            this._browser.setWebViewClient(this._browserClient);
            this._displayMetrics = new DisplayMetrics();
            ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay().getMetrics(this._displayMetrics);
            applyDefaultSettings();
            this._adsLoader.reload();
            return;
        }
        Log.e("Appsgeyser SDK", "You have to grant ACCESS_NETWORK_STATE and INTERNET permissions to work properly");
    }

    public void applyDefaultSettings() {
        setVerticalScrollBarEnabled(false);
        setHorizontalScrollBarEnabled(false);
        WebSettings settings = this._browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setAllowFileAccess(true);
        settings.setGeolocationEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setDomStorageEnabled(true);
        Context ctx = getContext();
        String appCachePath = ctx.getDir("appcache", 0).getPath();
        String databasePath = ctx.getDir("databases", 0).getPath();
        String geolocationDatabasePath = ctx.getDir("geolocation", 0).getPath();
        settings.setAppCachePath(appCachePath);
        settings.setDatabasePath(databasePath);
        settings.setGeolocationDatabasePath(geolocationDatabasePath);
        _applySize();
    }

    public void setWidth(int width) {
        if (width > 0) {
            this._width = width;
            _applySize();
        }
    }

    public void setHeight(int height) {
        if (height > 0) {
            this._height = height;
            _applySize();
        }
    }

    public WebView getBrowser() {
        return this._browser;
    }

    protected void _applySize() {
        ViewGroup.LayoutParams params = getLayoutParams();
        if (params == null) {
            return;
        }
        if (this._displayMetrics.widthPixels < this._width + 6) {
            params.width = this._displayMetrics.widthPixels;
            params.height = (int) (((((float) (this._displayMetrics.widthPixels - 6)) / ((float) this._width)) * ((float) this._height)) + 6.0f);
            return;
        }
        params.width = this._width + 6;
        params.height = this._height + 6;
    }

    public void acceptBehavior(BehaviorVisitor visitor) {
        if (visitor instanceof AdViewBehavior) {
            ((AdViewBehavior) visitor).visit(this);
        }
    }

    public void hide() {
        setVisibility(8);
        this._browser.setWebViewClient(null);
    }

    public void show() {
        setVisibility(0);
        this._browser.setWebViewClient(this._browserClient);
    }
}
