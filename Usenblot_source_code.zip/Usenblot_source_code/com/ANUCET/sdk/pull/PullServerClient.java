package com.appsgeyser.sdk.pull;

import android.content.Context;
import com.appsgeyser.sdk.configuration.Configuration;
import com.appsgeyser.sdk.configuration.Constants;
import com.google.android.gms.plus.PlusShare;
import java.net.URLEncoder;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

public class PullServerClient {
    private final String DOMAIN_URL_KEY;
    private final String LAST_REQUEST_TIME_KEY;
    private final int OK_RESPONSE;
    private Context _context;
    private onMessageReceivedListener _listener;

    /* renamed from: com.appsgeyser.sdk.pull.PullServerClient.1 */
    class C00911 extends Thread {
        private final /* synthetic */ onMessageReceivedListener val$onResponseListener;
        private final /* synthetic */ String val$requestUrl;

        C00911(String str, onMessageReceivedListener com_appsgeyser_sdk_pull_PullServerClient_onMessageReceivedListener) {
            this.val$requestUrl = str;
            this.val$onResponseListener = com_appsgeyser_sdk_pull_PullServerClient_onMessageReceivedListener;
        }

        public void run() {
            try {
                HttpClient client = new DefaultHttpClient();
                HttpGet httpGet = new HttpGet(this.val$requestUrl);
                httpGet.setHeader("Cache-Control", "no-cache,no-store");
                HttpResponse response = client.execute(httpGet);
                if (response.getStatusLine().getStatusCode() == 200) {
                    HttpEntity entity = response.getEntity();
                    if (entity != null) {
                        JSONObject json = new JSONObject(EntityUtils.toString(entity));
                        PullServerClient.this._setLastRequestTime(PullServerClient.this._context, json.getLong("timestamp"));
                        JSONArray jsonViewUrls = json.getJSONArray("data");
                        if (jsonViewUrls.length() > 0) {
                            Response[] responses = new Response[jsonViewUrls.length()];
                            for (int i = 0; i < jsonViewUrls.length(); i++) {
                                JSONObject row = jsonViewUrls.getJSONObject(i);
                                responses[i] = new Response();
                                responses[i].url = row.getString("data");
                                responses[i].message = row.getString("message");
                                responses[i].title = row.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE);
                            }
                            this.val$onResponseListener.onMessage(responses);
                            return;
                        }
                        return;
                    }
                    return;
                }
                PullServerClient.this._rotateDomainUrls(PullServerClient.this._context);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public class Response {
        String message;
        String title;
        String url;

        public Response() {
            this.url = Constants.PUBLISHER_NAME;
            this.title = Constants.PUBLISHER_NAME;
            this.message = Constants.PUBLISHER_NAME;
        }
    }

    public interface onMessageReceivedListener {
        void onMessage(Response[] responseArr);
    }

    public PullServerClient(Context context, onMessageReceivedListener listener) {
        this.OK_RESPONSE = 200;
        this.LAST_REQUEST_TIME_KEY = "last_pull_request_time";
        this.DOMAIN_URL_KEY = "domain_url";
        this._context = null;
        this._context = context;
        this._listener = listener;
    }

    public void tryLoadMessageAsync() {
        try {
            String pullServerUrl = _getDomainUrl(this._context);
            Configuration configuration = Configuration.getInstance();
            _sendRequestAsync(new StringBuilder(String.valueOf(pullServerUrl)).append("get_message.php?app_id=").append(configuration.getApplicationId()).append("&name=").append(URLEncoder.encode(this._context.getPackageName(), "utf-8")).append("&last_request_timestamp=").append(_getLastRequestTime(this._context)).append("&guid=").append(URLEncoder.encode(configuration.getAppGuid())).append("&sdk=1").toString(), this._listener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void _sendRequestAsync(String requestUrl, onMessageReceivedListener onResponseListener) {
        new C00911(requestUrl, onResponseListener).start();
    }

    private long _getLastRequestTime(Context context) {
        return context.getSharedPreferences(Constants.PREFS_NAME, 0).getLong("last_pull_request_time", System.currentTimeMillis() / 1000);
    }

    private void _setLastRequestTime(Context context, long newTime) {
        context.getSharedPreferences(Constants.PREFS_NAME, 0).edit().putLong("last_pull_request_time", newTime).commit();
    }

    private void _rotateDomainUrls(Context context) {
        String currentUrl = _getDomainUrl(context);
        String url1 = Constants.PULL_DOMAIN_URL3;
        String url2 = Constants.PULL_DOMAIN_URL3;
        String url3 = Constants.PULL_DOMAIN_URL3;
        if (currentUrl.equalsIgnoreCase(url1)) {
            _setDomainUrl(context, url2);
        } else if (currentUrl.equalsIgnoreCase(url2)) {
            _setDomainUrl(context, url3);
        } else if (currentUrl.equalsIgnoreCase(url3)) {
            _setDomainUrl(context, url1);
        } else {
            _setDomainUrl(context, url1);
        }
    }

    private String _getDomainUrl(Context context) {
        return context.getSharedPreferences(Constants.PREFS_NAME, 0).getString("domain_url", Constants.PULL_DOMAIN_URL3);
    }

    private void _setDomainUrl(Context context, String newUrl) {
        context.getSharedPreferences(Constants.PREFS_NAME, 0).edit().putString("domain_url", newUrl).commit();
    }
}
