package com.appsgeyser.sdk.pull;

import android.content.Context;
import com.appsgeyser.sdk.configuration.Configuration;
import com.appsgeyser.sdk.configuration.Constants;
import java.net.URLEncoder;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

public class StatServerClient {
    private Configuration _config;
    private Context _context;

    /* renamed from: com.appsgeyser.sdk.pull.StatServerClient.1 */
    class C00921 extends Thread {
        private final /* synthetic */ String val$requestUrl;

        C00921(String str) {
            this.val$requestUrl = str;
        }

        public void run() {
            try {
                HttpClient client = new DefaultHttpClient();
                HttpGet httpGet = new HttpGet(this.val$requestUrl);
                httpGet.setHeader("Cache-Control", "no-cache,no-store");
                client.execute(httpGet);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public StatServerClient(Context context) {
        this._context = null;
        this._context = context;
        Configuration configuration = Configuration.getInstance();
    }

    public void sendMessageAcceptedAsync(String messageUrl) {
        try {
            _sendRequestAsync(_createStatUrl("request", messageUrl));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void sendPushReceivedAsync(String messageUrl) {
        try {
            _sendRequestAsync(_createStatPushUrl("request", messageUrl));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void senMessageClickedAsync(String messageUrl) {
        try {
            _sendRequestAsync(_createStatUrl("click", messageUrl));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String _createStatUrl(String action, String messageUrl) {
        return "http://stat.appsgeyser.com/pull.php?a=" + action + "&url=" + URLEncoder.encode(messageUrl) + "&app=" + this._config.getApplicationId() + "&v=" + URLEncoder.encode(Constants.PLATFORM_VERSION) + "&guid=" + URLEncoder.encode(this._config.getAppGuid()) + "&sdk=1";
    }

    private String _createStatPushUrl(String action, String messageUrl) {
        return "http://stat.appsgeyser.com/push.php?a=" + action + "&url=" + URLEncoder.encode(messageUrl) + "&app=" + this._config.getApplicationId() + "&v=" + URLEncoder.encode(Constants.PLATFORM_VERSION) + "&guid=" + URLEncoder.encode(this._config.getAppGuid()) + "&sdk=1";
    }

    private void _sendRequestAsync(String requestUrl) {
        new C00921(requestUrl).start();
    }
}
