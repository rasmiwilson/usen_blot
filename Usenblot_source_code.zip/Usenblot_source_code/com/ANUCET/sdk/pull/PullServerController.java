package com.appsgeyser.sdk.pull;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.appsgeyser.sdk.AppsgeyserSDK;
import com.appsgeyser.sdk.configuration.Constants;
import com.appsgeyser.sdk.notifications.AppNotificationManager;
import com.appsgeyser.sdk.pull.PullServerClient.Response;
import com.appsgeyser.sdk.pull.PullServerClient.onMessageReceivedListener;
import com.google.android.gms.drive.DriveFile;

public class PullServerController extends BroadcastReceiver implements onMessageReceivedListener {
    private final long ALARM_PERIOD;
    private final String LAST_ALARM_TIME_KEY;
    private Context _context;

    public PullServerController() {
        this.LAST_ALARM_TIME_KEY = "last_alarm_time";
        this.ALARM_PERIOD = 5000;
        this._context = null;
    }

    public void onReceive(Context context, Intent intent) {
        if (AppsgeyserSDK.isPullEnabled()) {
            this._context = context;
            long lastAlarmTime = _getLastAlarmTime(context);
            long currentTime = System.currentTimeMillis();
            if (currentTime - lastAlarmTime >= 5000) {
                _setLastAlarmTime(context, currentTime);
                if (lastAlarmTime != 0) {
                    _pullMessage(context);
                }
            }
            reScheduleNotification(context);
        }
    }

    public void reScheduleNotification(Context context) {
        this._context = context;
        long lastAlarmTime = _getLastAlarmTime(context);
        if (lastAlarmTime < System.currentTimeMillis() - 5000) {
            lastAlarmTime = System.currentTimeMillis();
        }
        Intent intent = new Intent(context, PullServerController.class);
        PendingIntent pendingIntent0 = PendingIntent.getBroadcast(context, 0, intent, DriveFile.MODE_READ_ONLY);
        PendingIntent pendingIntent1 = PendingIntent.getBroadcast(context, 1, intent, DriveFile.MODE_READ_ONLY);
        PendingIntent pendingIntent2 = PendingIntent.getBroadcast(context, 2, intent, DriveFile.MODE_READ_ONLY);
        AlarmManager alarmManager = (AlarmManager) context.getSystemService("alarm");
        alarmManager.cancel(pendingIntent0);
        alarmManager.cancel(pendingIntent1);
        alarmManager.cancel(pendingIntent2);
        alarmManager.set(0, lastAlarmTime + 5000, pendingIntent0);
        alarmManager.set(0, 10000 + lastAlarmTime, pendingIntent1);
        alarmManager.set(0, 60000 + lastAlarmTime, pendingIntent2);
    }

    private void _pullMessage(Context context) {
        new PullServerClient(context, this).tryLoadMessageAsync();
    }

    private long _getLastAlarmTime(Context context) {
        return context.getSharedPreferences(Constants.PREFS_NAME, 0).getLong("last_alarm_time", 0);
    }

    private void _setLastAlarmTime(Context context, long newTime) {
        context.getSharedPreferences(Constants.PREFS_NAME, 0).edit().putLong("last_alarm_time", newTime).commit();
    }

    public void onMessage(Response[] responses) {
        for (Response r : responses) {
            String url = r.url;
            String message = r.message;
            String title = r.title;
            AppNotificationManager.generateNotification(this._context, message, title, AppNotificationManager.getLaunchIntent(this._context, title, url));
            new StatServerClient(this._context).sendMessageAcceptedAsync(url);
        }
    }
}
