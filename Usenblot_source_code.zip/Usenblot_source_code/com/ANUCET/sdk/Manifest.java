package com.appsgeyser.sdk;

public final class Manifest {

    public static final class permission {
        public static final String C2D_MESSAGE = "com.appsgeyser.multiTabApp.permission.C2D_MESSAGE";
    }
}
