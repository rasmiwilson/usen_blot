package com.appsgeyser.sdk;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.RelativeLayout;
import com.appsgeyser.sdk.pull.PullServerController;
import com.appsgeyser.sdk.webwiewclient.PushWebViewClient;
import com.google.android.gms.plus.PlusShare;

public class MessageViewer extends Activity {
    Activity _activity;
    WebView _browser;

    /* renamed from: com.appsgeyser.sdk.MessageViewer.1 */
    class C00761 extends WebChromeClient {
        C00761() {
        }
    }

    /* renamed from: com.appsgeyser.sdk.MessageViewer.2 */
    class C00772 implements OnClickListener {
        C00772() {
        }

        public void onClick(DialogInterface dialog, int which) {
        }
    }

    public MessageViewer() {
        this._activity = null;
        this._browser = null;
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this._activity = this;
        LinearLayout messageViewer = new LinearLayout(this._activity);
        messageViewer.setLayoutParams(new LayoutParams(-1, -1));
        WebView webView = new WebView(this._activity);
        webView.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
        messageViewer.addView(webView);
        setContentView(messageViewer);
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            setTitle(extras.getString(PlusShare.KEY_CONTENT_DEEP_LINK_METADATA_TITLE));
            String url = extras.getString(PlusShare.KEY_CALL_TO_ACTION_URL);
            if (url != null) {
                this._browser = webView;
                this._browser.loadUrl(url);
                this._browser.setWebViewClient(new PushWebViewClient(url, this));
                this._browser.setWebChromeClient(new C00761());
                WebSettings settings = this._browser.getSettings();
                settings.setJavaScriptEnabled(true);
                settings.setJavaScriptCanOpenWindowsAutomatically(true);
                settings.setAllowFileAccess(true);
                settings.setGeolocationEnabled(true);
                settings.setAppCacheMaxSize(5242880);
                this._browser.setVerticalScrollBarEnabled(false);
                this._browser.setHorizontalScrollBarEnabled(false);
                settings.setLoadWithOverviewMode(true);
                settings.setUseWideViewPort(true);
                settings.setBuiltInZoomControls(true);
                this._browser.setInitialScale(0);
            }
        }
        if (AppsgeyserSDKInternal.getInstance().pullEnabled()) {
            new PullServerController().reScheduleNotification(this);
        }
    }

    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode != 4) {
            return super.onKeyDown(keyCode, event);
        }
        this._activity.finish();
        return true;
    }

    protected void onStart() {
        super.onStart();
    }

    protected void onPause() {
        super.onPause();
        this._activity.finish();
    }

    protected void onDestroy() {
        super.onDestroy();
        destroyActivity();
    }

    private void destroyActivity() {
        if (this._browser != null) {
            this._browser.destroy();
            this._browser = null;
        }
    }

    public void showMessage(String text) {
        if (this._activity != null) {
            Builder builder = new Builder(this._activity);
            builder.setMessage(text);
            builder.setPositiveButton("ok", new C00772());
            builder.create().show();
        }
    }
}
