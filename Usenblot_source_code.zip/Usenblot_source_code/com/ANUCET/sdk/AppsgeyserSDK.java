package com.appsgeyser.sdk;

import android.app.Application;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;
import com.appsgeyser.player.UnityPlayerNativeActivity;
import com.appsgeyser.sdk.analytics.Analytics;

public class AppsgeyserSDK {
    public static String Apikey;
    public static Application application;

    /* renamed from: com.appsgeyser.sdk.AppsgeyserSDK.1 */
    class C00741 implements Runnable {
        C00741() {
        }

        public void run() {
            UnityPlayerNativeActivity.start_banners();
        }
    }

    /* renamed from: com.appsgeyser.sdk.AppsgeyserSDK.2 */
    class C00752 implements Runnable {
        C00752() {
        }

        public void run() {
        }
    }

    private static class SingletonHolder {
        public static final AppsgeyserSDK HOLDER_INSTANCE;

        private SingletonHolder() {
        }

        static {
            HOLDER_INSTANCE = new AppsgeyserSDK();
        }
    }

    public static boolean isOnline() {
        NetworkInfo netInfo = ((ConnectivityManager) UnityPlayerNativeActivity.mn.getSystemService("connectivity")).getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            return false;
        }
        return true;
    }

    public static boolean DownloudAllFile() {
        return false;
    }

    public static void makeBanner() {
        UnityPlayerNativeActivity.mn.runOnUiThread(new C00741());
    }

    public static void log(String st) {
        Log.i("Unity2", st);
    }

    public static int getBundleVersion() {
        int v = 0;
        try {
            return UnityPlayerNativeActivity.mn.getPackageManager().getPackageInfo(UnityPlayerNativeActivity.mn.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            return v;
        }
    }

    public static boolean sendApiKey(String APIKey) {
        boolean res = APIKey != null && APIKey.length() > 0;
        Log.d("unity", "api_get");
        if (res) {
            Apikey = APIKey;
            takeOff();
            Log.d("unity", "take off");
            Analytics analytics = getAnalytics();
            if (analytics != null) {
                Log.d("unity", "analytics true");
            }
            if (analytics != null) {
                analytics.ActivityStarted();
                Log.d("unity", "ActivityStarted");
                UnityPlayerNativeActivity.mn.runOnUiThread(new C00752());
            }
        }
        return res;
    }

    public static boolean check() {
        if (application != null) {
            return true;
        }
        return false;
    }

    public static void takeOff() {
        AppsgeyserSDKInternal.takeOff(application, Apikey);
    }

    public static void takeOff(Application application, String APIkey) {
        AppsgeyserSDKInternal.takeOff(application, APIkey);
    }

    public static Analytics getAnalytics() {
        return AppsgeyserSDKInternal.getAnalytics();
    }

    public static void enablePush() {
        AppsgeyserSDKInternal.enablePush();
        Log.i("UNITY", "enagle push");
    }

    public static void enablePull() {
        AppsgeyserSDKInternal.enablePull();
    }

    public static boolean isPushEnabled() {
        return AppsgeyserSDKInternal.getInstance().pushEnabled();
    }

    public static boolean isPullEnabled() {
        return AppsgeyserSDKInternal.getInstance().pullEnabled();
    }

    private AppsgeyserSDK() {
    }

    protected static AppsgeyserSDK getInstance() {
        return SingletonHolder.HOLDER_INSTANCE;
    }
}
