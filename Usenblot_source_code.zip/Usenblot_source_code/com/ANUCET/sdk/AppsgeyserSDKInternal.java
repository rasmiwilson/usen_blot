package com.appsgeyser.sdk;

import android.app.Application;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Handler;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import com.appsgeyser.sdk.analytics.Analytics;
import com.appsgeyser.sdk.configuration.Configuration;
import com.appsgeyser.sdk.configuration.Constants;
import com.appsgeyser.sdk.configuration.PreferencesCoder;
import com.appsgeyser.sdk.pull.PullServerController;
import com.appsgeyser.sdk.server.PushServerClient;
import com.appsgeyser.sdk.server.implementation.AppsgeyserServerClient;

public class AppsgeyserSDKInternal {
    protected Analytics _analytics;
    protected Application _application;
    protected Configuration _configuration;
    protected boolean _enablePull;
    protected boolean _enablePush;
    AppsgeyserServerClient _serverClient;

    private static class SingletonHolder {
        public static final AppsgeyserSDKInternal HOLDER_INSTANCE;

        private SingletonHolder() {
        }

        static {
            HOLDER_INSTANCE = new AppsgeyserSDKInternal();
        }
    }

    public static void takeOff(Application application, String APIkey) {
        getInstance()._takeOff(application, APIkey);
    }

    public static Analytics getAnalytics() {
        return getInstance()._analytics;
    }

    public static void enablePush() {
        getInstance().setPushEnabled(true);
    }

    public static void enablePull() {
        getInstance().setPullEnabled(true);
    }

    public static void runOnMainThread(Runnable blockToExecute) {
        getInstance();
        Application application = getApplication();
        if (application != null && blockToExecute != null) {
            runOnMainThread(application, blockToExecute);
        }
    }

    public static void runOnMainThread(Context context, Runnable blockToExecute) {
        if (context != null && blockToExecute != null) {
            new Handler(context.getMainLooper()).post(blockToExecute);
        }
    }

    private AppsgeyserSDKInternal() {
        this._application = null;
        this._configuration = null;
        this._analytics = null;
        this._enablePush = false;
        this._enablePull = false;
    }

    public boolean pushEnabled() {
        return this._enablePush;
    }

    public boolean pullEnabled() {
        return this._enablePull;
    }

    public void setPushEnabled(boolean _enablePush) {
        this._enablePush = _enablePush;
    }

    public void setPullEnabled(boolean _enablePull) {
        this._enablePull = _enablePull;
    }

    protected static AppsgeyserSDKInternal getInstance() {
        return SingletonHolder.HOLDER_INSTANCE;
    }

    public static Application getApplication() {
        return SingletonHolder.HOLDER_INSTANCE._application;
    }

    private void _takeOff(Application application, String APIkey) {
        if (application != null && StringUtils.isNotNullOrEmptyString(APIkey) && _checkPermissions(application)) {
            _checkActivityDeclared(application, "com.appsgeyser.sdk.MessageViewer");
            _init(application);
            this._configuration = Configuration.getInstance();
            if (!(this._configuration.getApplicationId() != null ? this._configuration.getApplicationId() : Constants.PUBLISHER_NAME).equals(APIkey)) {
                this._configuration.clearApplicationSettings();
                this._configuration.setApplicationId(APIkey);
            }
            if (this._enablePush) {
                new PushServerClient().loadPushAccount();
            }
            if (this._enablePull) {
                new PullServerController().reScheduleNotification(application);
            }
        }
    }

    private void _init(Application application) {
        this._application = application;
        this._configuration = Configuration.getInstance();
        this._configuration.setSettingsCoder(new PreferencesCoder(this._application, Constants.PREFS_NAME));
        this._configuration.loadConfiguration();
        this._analytics = new Analytics();
    }

    private boolean _checkPermissions(Application application) {
        if (application.checkCallingOrSelfPermission("android.permission.ACCESS_NETWORK_STATE") == 0 && application.checkCallingOrSelfPermission("android.permission.INTERNET") == 0) {
            if (this._enablePush) {
                PackageManager packageManager = application.getPackageManager();
                String packageName = application.getPackageName();
                try {
                    packageManager.getPermissionInfo(new StringBuilder(String.valueOf(packageName)).append(".permission.C2D_MESSAGE").toString(), AccessibilityNodeInfoCompat.ACTION_SCROLL_FORWARD);
                } catch (NameNotFoundException e) {
                    ExceptionHandler.handleException(new Exception("Invalid permission. You have to grant " + packageName + ".permission.C2D_MESSAGE" + " and com.google.android.c2dm.permission.RECEIVE permissions to work properly"));
                    return false;
                }
            }
            return true;
        }
        ExceptionHandler.handleException(new Exception("Invalid permission. You have to grant ACCESS_NETWORK_STATE and INTERNET permissions to work properly"));
        return false;
    }

    private boolean _checkActivityDeclared(Application application, String className) {
        try {
            application.getPackageManager().getActivityInfo(new ComponentName(application, className), 1);
            return true;
        } catch (NameNotFoundException e) {
            ExceptionHandler.handleException(new Exception("Activity " + className + " is non-declared in manifest!"));
            return false;
        }
    }
}
