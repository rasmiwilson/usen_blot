package android.support.v4.media;

public class TransportStateListener {
    public void onPlayingChanged(TransportController controller) {
    }

    public void onTransportControlsChanged(TransportController controller) {
    }
}
