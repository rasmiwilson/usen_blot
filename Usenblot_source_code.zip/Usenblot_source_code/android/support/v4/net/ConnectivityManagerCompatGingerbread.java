package android.support.v4.net;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import com.google.android.gms.wallet.NotifyTransactionStatusRequest.Status.Error;
import com.google.tagmanager.protobuf.nano.CodedOutputByteBufferNano;

class ConnectivityManagerCompatGingerbread {
    ConnectivityManagerCompatGingerbread() {
    }

    public static boolean isActiveNetworkMetered(ConnectivityManager cm) {
        NetworkInfo info = cm.getActiveNetworkInfo();
        if (info == null) {
            return true;
        }
        switch (info.getType()) {
            case Base64Encoder.DEFAULT /*0*/:
            case Base64Encoder.URL_SAFE /*2*/:
            case Error.BAD_CVC /*3*/:
            case CodedOutputByteBufferNano.LITTLE_ENDIAN_32_SIZE /*4*/:
            case Error.DECLINED /*5*/:
            case Error.OTHER /*6*/:
                return true;
            case Base64Encoder.NO_PADDING /*1*/:
                return false;
            default:
                return true;
        }
    }
}
